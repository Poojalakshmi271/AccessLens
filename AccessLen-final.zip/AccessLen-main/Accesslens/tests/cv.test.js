'use strict';
const test   = require('node:test');
const assert = require('node:assert/strict');
const { iou, centreDistance, Kalman1D, ObjectTracker, PerfMonitor, SessionRecorder, percentile } =
  require('../public/cv.js');

// Deterministic PRNG so tests never flake
function rng(seed) {
  return function () {
    seed |= 0; seed = (seed + 0x6D2B79F5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const noisy = (r, v, frac) => v * (1 + (r() * 2 - 1) * frac);
const near = (a, b, tol, msg) => assert.ok(Math.abs(a - b) <= tol, `${msg || ''} expected ${b} ± ${tol}, got ${a}`);

// A "person" box whose size shrinks/grows with distance (pinhole model)
const boxAt = (cx, dist) => { const h = 300 / dist, w = h * 0.4; return [cx - w / 2, 400 - h, w, h]; };

test('iou: identical, disjoint, half-overlap', () => {
  assert.equal(iou([0, 0, 10, 10], [0, 0, 10, 10]), 1);
  assert.equal(iou([0, 0, 10, 10], [20, 20, 5, 5]), 0);
  near(iou([0, 0, 10, 10], [5, 0, 10, 10]), 1 / 3, 1e-9);
});

test('centreDistance is scale-free', () => {
  near(centreDistance([0, 0, 10, 10], [5, 0, 10, 10]), 0.5, 1e-9);
});

test('Kalman1D converges to a constant closing speed and smooths noise', () => {
  const r = rng(1); const kf = new Kalman1D(6);
  let rawErr = 0, smoothErr = 0, n = 0;
  for (let i = 1; i <= 40; i++) {
    const truth = 6 - 1.2 * (i * 0.1);
    kf.predict(0.1);
    const z = noisy(r, truth, 0.10);
    kf.update(z);
    if (i > 15) { rawErr += Math.abs(z - truth); smoothErr += Math.abs(kf.d - truth); n++; }
  }
  near(-kf.v, 1.2, 0.35, 'closing speed');
  assert.ok(smoothErr / n < rawErr / n, 'smoothed error should be lower than raw error');
});

test('tracker keeps one stable ID for an approaching object and estimates TTC', () => {
  const r = rng(7); const tr = new ObjectTracker();
  const ids = new Set(); let last;
  for (let i = 0; i < 30; i++) {
    const now = i * 100, truth = 6 - 1.2 * (now / 1000);
    const dets = [{ bbox: boxAt(320, truth), label: 'person', score: 0.9, dist: noisy(r, truth, 0.08) }];
    tr.update(dets, now);
    ids.add(tr.tracks[0].id); last = tr.tracks[0];
  }
  assert.equal(ids.size, 1, 'ID must not change');
  assert.ok(last.confirmed);
  const truthNow = 6 - 1.2 * 2.9;
  near(last.speed, 1.2, 0.4, 'speed');
  assert.ok(last.ttc !== null, 'approaching object should have TTC');
  near(last.ttc, truthNow / 1.2, 1.6, 'ttc');
});

test('stationary and receding objects have no TTC', () => {
  const r = rng(3);
  const stat = new ObjectTracker(), recede = new ObjectTracker();
  for (let i = 0; i < 30; i++) {
    const now = i * 100;
    stat.update([{ bbox: boxAt(300, 4), label: 'chair', score: .8, dist: noisy(r, 4, .06) }], now);
    const td = 2 + 1.0 * (now / 1000);
    recede.update([{ bbox: boxAt(300, td), label: 'person', score: .8, dist: noisy(r, td, .06) }], now);
  }
  assert.equal(stat.tracks[0].ttc, null);
  assert.equal(recede.tracks[0].ttc, null);
});

test('two objects of the same class keep separate IDs', () => {
  const tr = new ObjectTracker();
  let a, b;
  for (let i = 0; i < 12; i++) {
    tr.update([
      { bbox: boxAt(150, 3), label: 'person', score: .9, dist: 3 },
      { bbox: boxAt(520, 3), label: 'person', score: .9, dist: 3 },
    ], i * 100);
  }
  assert.equal(tr.tracks.length, 2);
  [a, b] = tr.tracks;
  assert.notEqual(a.id, b.id);
  assert.ok(a.confirmed && b.confirmed);
});

test('different class at the same place is NOT matched to the old track', () => {
  const tr = new ObjectTracker();
  for (let i = 0; i < 5; i++) tr.update([{ bbox: boxAt(300, 3), label: 'person', score: .9, dist: 3 }], i * 100);
  tr.update([{ bbox: boxAt(300, 3), label: 'dog', score: .9, dist: 3 }], 500);
  const labels = tr.tracks.map(t => t.label).sort();
  assert.deepEqual(labels, ['dog', 'person']);
});

test('tracks are dropped after maxAgeMs and a new ID is issued on return', () => {
  const tr = new ObjectTracker({ maxAgeMs: 500 });
  for (let i = 0; i < 4; i++) tr.update([{ bbox: boxAt(300, 3), label: 'person', score: .9, dist: 3 }], i * 100);
  const firstId = tr.tracks[0].id;
  tr.update([], 600);   assert.equal(tr.tracks.length, 1, 'still coasting');
  tr.update([], 1200);  assert.equal(tr.tracks.length, 0, 'dropped');
  tr.update([{ bbox: boxAt(300, 3), label: 'person', score: .9, dist: 3 }], 1300);
  assert.notEqual(tr.tracks[0].id, firstId);
});

test('track is only confirmed after minHits and never gets TTC while coasting', () => {
  const tr = new ObjectTracker({ minHits: 3 });
  tr.update([{ bbox: boxAt(300, 5), label: 'car', score: .9, dist: 5 }], 0);
  assert.equal(tr.tracks[0].confirmed, false);
  tr.update([{ bbox: boxAt(300, 4.9), label: 'car', score: .9, dist: 4.9 }], 100);
  tr.update([{ bbox: boxAt(300, 4.8), label: 'car', score: .9, dist: 4.8 }], 200);
  assert.equal(tr.tracks[0].confirmed, true);
  tr.update([], 300);
  assert.equal(tr.tracks[0].detIndex, -1);
  assert.equal(tr.tracks[0].ttc, null);
});

test('centre-distance fallback re-associates a fast-moving box (low IoU)', () => {
  const tr = new ObjectTracker();
  tr.update([{ bbox: [100, 100, 50, 100], label: 'person', score: .9, dist: 3 }], 0);
  tr.update([{ bbox: [140, 100, 50, 100], label: 'person', score: .9, dist: 3 }], 100); // IoU ≈ 0.11
  assert.equal(tr.tracks.length, 1);
  assert.equal(tr.tracks[0].hits, 2);
});

test('percentile interpolates', () => {
  assert.equal(percentile([1, 2, 3, 4, 5], 0.5), 3);
  near(percentile([10, 20], 0.95), 19.5, 1e-9);
  assert.equal(percentile([], 0.5), 0);
});

test('PerfMonitor: live stats and benchmark result', () => {
  const pm = new PerfMonitor();
  let done = null; pm.onBenchmarkDone = r => { done = r; };
  pm.startBenchmark(1000, { backend: 'webgl' }, 0);
  for (let i = 1; i <= 21; i++) pm.recordFrame(20 + (i % 5), i * 50);   // 20 FPS for 1.05 s
  const s = pm.stats();
  near(s.fps, 20, 0.5, 'fps'); near(s.meanMs, 22, 1.5, 'mean');
  assert.ok(done, 'benchmark should finish');
  assert.equal(done.backend, 'webgl');
  near(done.fps, 20, 1.5, 'bench fps');
  assert.ok(done.p95Ms >= done.p50Ms);
  assert.equal(pm.benchmarking, false);
});

test('SessionRecorder throttles per track and produces valid CSV', () => {
  const rec = new SessionRecorder({ sampleEveryMs: 500 });
  const t = { id: 1, label: 'person, "adult"', score: .91, rawDist: 3.1234, dist: 3.0, speed: 0.8, ttc: 3.75 };
  assert.equal(rec.maybeAdd(t, { inPath: true, risk: 'high', fps: 14.2 }, 0), true);
  assert.equal(rec.maybeAdd(t, { inPath: true, risk: 'high', fps: 14.2 }, 200), false);
  assert.equal(rec.maybeAdd(t, { inPath: false, risk: 'high', fps: 14.2 }, 700), true);
  const lines = rec.toCSV().split('\n');
  assert.equal(lines.length, 3);
  assert.equal(lines[0], 't_s,track_id,label,score,dist_raw_m,dist_smooth_m,closing_speed_mps,ttc_s,in_path,risk,detect_fps');
  assert.ok(lines[1].includes('"person, ""adult"""'), 'label with comma/quotes must be escaped');
});
