"""
Generates analysis/sample_session.csv  –  SYNTHETIC DEMO DATA, not real measurements.

It mimics the CSV exported by the app (Detection → Perf panel → 📥) so the notebook
can be run end-to-end without a phone. Replace it with your own export for real analysis.
"""
import numpy as np, pandas as pd

rng = np.random.default_rng(42)
COLUMNS = ["t_s", "track_id", "label", "score", "dist_raw_m", "dist_smooth_m",
           "closing_speed_mps", "ttc_s", "in_path", "risk", "detect_fps"]
RISK = {"person": "high", "car": "high", "bicycle": "high", "chair": "medium",
        "bench": "medium", "dog": "medium", "backpack": "low"}

def smooth(z, dt, q=1.0):
    """Same constant-velocity Kalman filter as public/cv.js (for generating realistic columns)."""
    d, v = z[0], 0.0
    P = np.array([[1.0, 0], [0, 4.0]])
    out_d, out_v = [d], [v]
    for zi in z[1:]:
        F = np.array([[1, dt], [0, 1]]); Q = q * np.array([[dt**3/3, dt**2/2], [dt**2/2, dt]])
        d, v = d + v*dt, v
        P = F @ P @ F.T + Q
        R = max(0.05, 0.10*zi)**2
        S = P[0, 0] + R; K = P[:, 0] / S; y = zi - d
        d += K[0]*y; v += K[1]*y
        P = P - np.outer(K, P[0, :])
        out_d.append(d); out_v.append(v)
    return np.array(out_d), -np.array(out_v)   # speed: + = closing

rows, tid, t_cursor = [], 0, 0.0
scenarios = (["person_approach"]*10 + ["person_pass"]*8 + ["car_approach"]*4 +
             ["static_chair"]*9 + ["static_bench"]*4 + ["dog_cross"]*3 + ["bicycle_pass"]*3)
rng.shuffle(scenarios)
fps_base = 14.0
for sc in scenarios:
    tid += 1
    dt = 0.5                                  # app samples each track every 0.5 s
    n = int(rng.integers(6, 22))
    label, start, v = {
        "person_approach": ("person", rng.uniform(3.5, 8), rng.uniform(0.6, 1.6)),
        "person_pass":     ("person", rng.uniform(3, 6),   rng.uniform(-0.8, 0.2)),
        "car_approach":    ("car",    rng.uniform(6, 12),  rng.uniform(1.5, 4.0)),
        "static_chair":    ("chair",  rng.uniform(1.5, 5), 0.0),
        "static_bench":    ("bench",  rng.uniform(2, 6),   0.0),
        "dog_cross":       ("dog",    rng.uniform(2, 5),   rng.uniform(-0.3, 0.6)),
        "bicycle_pass":    ("bicycle", rng.uniform(4, 9),  rng.uniform(1.0, 3.0)),
    }[sc]
    t = np.arange(n) * dt
    truth = np.clip(start - v * t, 0.4, None)
    raw = truth * (1 + rng.normal(0, 0.09, n))
    sm, spd = smooth(raw, dt)
    for i in range(n):
        ttc = sm[i] / spd[i] if (i >= 4 and spd[i] >= 0.3 and sm[i] > 0) else np.nan
        if ttc > 20: ttc = np.nan
        in_path = int(sm[i] < 5 and rng.random() < 0.8) if sc != "static_bench" else int(rng.random() < 0.2)
        rows.append([round(t_cursor + t[i], 2), tid, label, round(float(np.clip(rng.normal(0.8, 0.1), .4, .99)), 3),
                     round(float(raw[i]), 2), round(float(sm[i]), 2), round(float(spd[i]), 2),
                     "" if np.isnan(ttc) else round(float(ttc), 1), in_path, RISK[label],
                     round(float(rng.normal(fps_base, 1.5)), 1)])
    t_cursor += t[-1] + rng.uniform(1, 5)

df = pd.DataFrame(rows, columns=COLUMNS).sort_values("t_s").reset_index(drop=True)
df.to_csv("analysis/sample_session.csv", index=False)
print(f"wrote analysis/sample_session.csv  ({len(df)} rows, {df.track_id.nunique()} tracks)")
