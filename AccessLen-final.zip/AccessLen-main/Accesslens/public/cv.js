/* =====================================================================
   ACCESSLENS – cv.js
   Pure logic (no DOM) so it can be unit-tested in Node and reused in the browser.

   • iou()            – intersection-over-union of two [x, y, w, h] boxes
   • Kalman1D         – constant-velocity Kalman filter on a distance signal
   • ObjectTracker    – multi-object tracker (IoU + centre-distance matching),
                        stable IDs, smoothed distance, closing speed, time-to-collision
   • PerfMonitor      – FPS / inference-latency statistics + timed benchmarks
   • SessionRecorder  – per-track samples → CSV (for the analysis notebook)
   ===================================================================== */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.AccessLensCV = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  /* ── Geometry ─────────────────────────────────────── */
  function iou(a, b) {
    const ax2 = a[0] + a[2], ay2 = a[1] + a[3];
    const bx2 = b[0] + b[2], by2 = b[1] + b[3];
    const iw = Math.min(ax2, bx2) - Math.max(a[0], b[0]);
    const ih = Math.min(ay2, by2) - Math.max(a[1], b[1]);
    if (iw <= 0 || ih <= 0) return 0;
    const inter = iw * ih;
    const union = a[2] * a[3] + b[2] * b[3] - inter;
    return union > 0 ? inter / union : 0;
  }

  // Distance between box centres, normalised by the larger box side (scale-free)
  function centreDistance(a, b) {
    const dx = (a[0] + a[2] / 2) - (b[0] + b[2] / 2);
    const dy = (a[1] + a[3] / 2) - (b[1] + b[3] / 2);
    const scale = Math.max(a[2], a[3], b[2], b[3], 1);
    return Math.hypot(dx, dy) / scale;
  }

  /* ── Kalman filter: state [distance, velocity] ────── */
  class Kalman1D {
    /**
     * @param {number} d0        first distance measurement (m)
     * @param {object} opts      q: process-noise (accel. spectral density), rFrac/rMin: measurement noise
     */
    constructor(d0, opts = {}) {
      this.q     = opts.q     ?? 1.0;    // how quickly closing speed may change
      this.rFrac = opts.rFrac ?? 0.10;   // measurement std-dev as a fraction of distance
      this.rMin  = opts.rMin  ?? 0.05;   // …with a floor (m)
      this.d = d0;
      this.v = 0;
      // covariance P = [[p00, p01], [p10, p11]]
      this.p00 = 1.0; this.p01 = 0; this.p10 = 0; this.p11 = 4.0;
      this.updates = 1;
    }

    predict(dt) {
      if (dt <= 0) return;
      // x = F x, with F = [[1, dt], [0, 1]]
      this.d += this.v * dt;
      // P = F P Fᵀ + Q
      const { p00, p01, p10, p11, q } = this;
      const dt2 = dt * dt, dt3 = dt2 * dt;
      this.p00 = p00 + dt * (p10 + p01) + dt2 * p11 + q * dt3 / 3;
      this.p01 = p01 + dt * p11 + q * dt2 / 2;
      this.p10 = p10 + dt * p11 + q * dt2 / 2;
      this.p11 = p11 + q * dt;
    }

    update(z) {
      const sd = Math.max(this.rMin, this.rFrac * Math.max(z, 0));
      const R  = sd * sd;
      const S  = this.p00 + R;
      const k0 = this.p00 / S;
      const k1 = this.p10 / S;
      const y  = z - this.d;
      this.d += k0 * y;
      this.v += k1 * y;
      const { p00, p01 } = this;
      this.p00 = (1 - k0) * p00;
      this.p01 = (1 - k0) * p01;
      this.p10 = this.p10 - k1 * p00;
      this.p11 = this.p11 - k1 * p01;
      this.updates++;
    }
  }

  /* ── Multi-object tracker ─────────────────────────── */
  class ObjectTracker {
    /**
     * Options (all optional):
     *  iouThreshold      min IoU to match a detection to a track      (0.25)
     *  centreThreshold   fallback: max normalised centre distance     (0.75)
     *  maxAgeMs          drop a track unseen for this long            (900)
     *  minHits           detections needed before a track is confirmed (3)
     *  minUpdatesForTTC  Kalman updates before speed/TTC are trusted   (5)
     *  approachSpeedMin  m/s closing speed that counts as "approaching" (0.3)
     *  ttcMaxS           ignore TTC values larger than this (s)        (20)
     */
    constructor(opts = {}) {
      this.iouThreshold     = opts.iouThreshold     ?? 0.25;
      this.centreThreshold  = opts.centreThreshold  ?? 0.75;
      this.maxAgeMs         = opts.maxAgeMs         ?? 900;
      this.minHits          = opts.minHits          ?? 3;
      this.minUpdatesForTTC = opts.minUpdatesForTTC ?? 5;
      this.approachSpeedMin = opts.approachSpeedMin ?? 0.3;
      this.ttcMaxS          = opts.ttcMaxS          ?? 20;
      this.kalmanOpts       = opts.kalman           ?? {};
      this.tracks  = [];
      this._nextId = 1;
    }

    reset() { this.tracks = []; this._nextId = 1; }

    /**
     * @param {Array<{bbox:number[], label:string, score:number, dist:number}>} dets
     * @param {number} nowMs  monotonic timestamp (e.g. performance.now())
     * @returns {Array} alive tracks; each has detIndex (index into `dets`, or -1 if coasting)
     */
    update(dets, nowMs) {
      // 1) predict every track forward to "now"
      for (const t of this.tracks) {
        const dt = Math.min(Math.max((nowMs - t.lastPredictMs) / 1000, 0), 1.0);
        t.kf.predict(dt);
        t.lastPredictMs = nowMs;
        t.detIndex = -1;
      }

      // 2) greedy matching: best IoU first, then centre-distance fallback
      const matchedTrack = new Set();
      const matchedDet   = new Set();

      const assign = (pairs) => {
        for (const p of pairs) {
          if (matchedTrack.has(p.ti) || matchedDet.has(p.di)) continue;
          matchedTrack.add(p.ti); matchedDet.add(p.di);
          this._applyDetection(this.tracks[p.ti], dets[p.di], p.di, nowMs);
        }
      };

      const iouPairs = [];
      for (let ti = 0; ti < this.tracks.length; ti++) {
        for (let di = 0; di < dets.length; di++) {
          if (this.tracks[ti].label !== dets[di].label) continue;
          const v = iou(this.tracks[ti].bbox, dets[di].bbox);
          if (v >= this.iouThreshold) iouPairs.push({ ti, di, v });
        }
      }
      iouPairs.sort((a, b) => b.v - a.v);
      assign(iouPairs);

      const cPairs = [];
      for (let ti = 0; ti < this.tracks.length; ti++) {
        if (matchedTrack.has(ti)) continue;
        for (let di = 0; di < dets.length; di++) {
          if (matchedDet.has(di) || this.tracks[ti].label !== dets[di].label) continue;
          const c = centreDistance(this.tracks[ti].bbox, dets[di].bbox);
          if (c <= this.centreThreshold) cPairs.push({ ti, di, v: c });
        }
      }
      cPairs.sort((a, b) => a.v - b.v);
      assign(cPairs);

      // 3) unmatched detections → new tracks
      for (let di = 0; di < dets.length; di++) {
        if (matchedDet.has(di)) continue;
        const d = dets[di];
        const kf = new Kalman1D(d.dist, this.kalmanOpts);
        const t = {
          id: this._nextId++, label: d.label, bbox: d.bbox.slice(), score: d.score,
          rawDist: d.dist, dist: d.dist, speed: 0, ttc: null,
          hits: 1, confirmed: this.minHits <= 1,
          firstSeenMs: nowMs, lastSeenMs: nowMs, lastPredictMs: nowMs,
          detIndex: di, kf,
        };
        this.tracks.push(t);
      }

      // 4) drop stale tracks, refresh derived values of the survivors
      this.tracks = this.tracks.filter(t => nowMs - t.lastSeenMs <= this.maxAgeMs);
      for (const t of this.tracks) this._refreshDerived(t);

      return this.tracks;
    }

    confirmed() { return this.tracks.filter(t => t.confirmed); }

    _applyDetection(t, det, di, nowMs) {
      t.bbox = det.bbox.slice();
      t.score = det.score;
      t.rawDist = det.dist;
      t.hits++;
      t.lastSeenMs = nowMs;
      t.detIndex = di;
      t.kf.update(det.dist);
      if (t.hits >= this.minHits) t.confirmed = true;
    }

    _refreshDerived(t) {
      t.dist  = Math.max(0, t.kf.d);
      t.speed = -t.kf.v;                      // + = getting closer (m/s)
      const trusted = t.kf.updates >= this.minUpdatesForTTC && t.detIndex >= 0;
      if (trusted && t.speed >= this.approachSpeedMin && t.dist > 0) {
        const ttc = t.dist / t.speed;
        t.ttc = ttc <= this.ttcMaxS ? ttc : null;
      } else {
        t.ttc = null;
      }
    }
  }

  /* ── Performance monitor ──────────────────────────── */
  function percentile(sorted, p) {
    if (!sorted.length) return 0;
    const idx = (sorted.length - 1) * p;
    const lo = Math.floor(idx), hi = Math.ceil(idx);
    return sorted[lo] + (sorted[hi] - sorted[lo]) * (idx - lo);
  }

  class PerfMonitor {
    constructor(opts = {}) {
      this.windowSize = opts.windowSize ?? 120;   // frames kept for live stats
      this.inferMs = [];
      this.stamps  = [];
      this.totalFrames = 0;
      this.bench = null;
      this.onBenchmarkDone = null;
    }

    recordFrame(inferMs, nowMs) {
      this.totalFrames++;
      this.inferMs.push(inferMs); this.stamps.push(nowMs);
      if (this.inferMs.length > this.windowSize) { this.inferMs.shift(); this.stamps.shift(); }

      if (this.bench) {
        this.bench.samples.push(inferMs);
        if (nowMs - this.bench.startMs >= this.bench.durationMs) this._finishBenchmark(nowMs);
      }
    }

    /** Live stats over the recent window */
    stats() {
      const n = this.inferMs.length;
      if (n === 0) return { frames: 0, fps: 0, meanMs: 0, p50Ms: 0, p95Ms: 0 };
      const sorted = this.inferMs.slice().sort((a, b) => a - b);
      const span = (this.stamps[n - 1] - this.stamps[0]) / 1000;
      return {
        frames: this.totalFrames,
        fps: n > 1 && span > 0 ? (n - 1) / span : 0,
        meanMs: this.inferMs.reduce((s, v) => s + v, 0) / n,
        p50Ms: percentile(sorted, 0.5),
        p95Ms: percentile(sorted, 0.95),
      };
    }

    startBenchmark(durationMs, meta, nowMs) {
      this.bench = { durationMs, meta: meta || {}, startMs: nowMs, samples: [] };
    }
    get benchmarking() { return !!this.bench; }
    benchmarkProgress(nowMs) {
      return this.bench ? Math.min(1, (nowMs - this.bench.startMs) / this.bench.durationMs) : 0;
    }
    cancelBenchmark() { this.bench = null; }

    _finishBenchmark(nowMs) {
      const b = this.bench; this.bench = null;
      const sorted = b.samples.slice().sort((a, c) => a - c);
      const secs = (nowMs - b.startMs) / 1000;
      const result = {
        ...b.meta,
        frames: b.samples.length,
        durationS: +secs.toFixed(2),
        fps: +(b.samples.length / secs).toFixed(2),
        meanMs: +(b.samples.reduce((s, v) => s + v, 0) / Math.max(1, b.samples.length)).toFixed(2),
        p50Ms: +percentile(sorted, 0.5).toFixed(2),
        p95Ms: +percentile(sorted, 0.95).toFixed(2),
      };
      if (typeof this.onBenchmarkDone === 'function') this.onBenchmarkDone(result);
      return result;
    }
  }

  /* ── Session recorder → CSV ───────────────────────── */
  const SESSION_COLUMNS = [
    't_s', 'track_id', 'label', 'score', 'dist_raw_m', 'dist_smooth_m',
    'closing_speed_mps', 'ttc_s', 'in_path', 'risk', 'detect_fps',
  ];

  class SessionRecorder {
    constructor(opts = {}) {
      this.maxRows = opts.maxRows ?? 20000;
      this.sampleEveryMs = opts.sampleEveryMs ?? 500;
      this.rows = [];
      this.startMs = null;
      this._lastSample = new Map();   // track id → last sampled timestamp
    }
    clear() { this.rows = []; this.startMs = null; this._lastSample.clear(); }

    /** Record at most one row per track per sampleEveryMs */
    maybeAdd(track, extra, nowMs) {
      if (this.startMs === null) this.startMs = nowMs;
      const last = this._lastSample.get(track.id);
      if (last !== undefined && nowMs - last < this.sampleEveryMs) return false;
      this._lastSample.set(track.id, nowMs);
      const r2 = (v, n = 2) => (v == null || !isFinite(v)) ? '' : +v.toFixed(n);
      this.rows.push({
        t_s: r2((nowMs - this.startMs) / 1000, 2),
        track_id: track.id,
        label: track.label,
        score: r2(track.score, 3),
        dist_raw_m: r2(track.rawDist),
        dist_smooth_m: r2(track.dist),
        closing_speed_mps: r2(track.speed),
        ttc_s: r2(track.ttc, 1),
        in_path: extra.inPath ? 1 : 0,
        risk: extra.risk || '',
        detect_fps: r2(extra.fps, 1),
      });
      if (this.rows.length > this.maxRows) this.rows.shift();
      return true;
    }

    toCSV() {
      const esc = v => {
        const s = String(v ?? '');
        return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
      };
      const lines = [SESSION_COLUMNS.join(',')];
      for (const r of this.rows) lines.push(SESSION_COLUMNS.map(c => esc(r[c])).join(','));
      return lines.join('\n');
    }
  }

  return { iou, centreDistance, Kalman1D, ObjectTracker, PerfMonitor, SessionRecorder, SESSION_COLUMNS, percentile };
});
