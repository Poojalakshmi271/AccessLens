/* ====================================================================
   ACCESSLENS – sw.js (v4)
   Works from any sub-path (GitHub Pages: /repo-name/) – all URLs relative.
   • App shell: network-first, cache fallback (offline start works)
   • CDN libs / model weights / fonts: cache-first, so detection works offline
   • /api/* and non-GET requests are never intercepted
   ==================================================================== */

const CACHE_NAME = 'accesslens-v4';
const PRECACHE = ['./', 'index.html', 'style.css', 'app.js', 'cv.js', 'manifest.json',
                  'icons/icon-192.png', 'icons/icon-512.png'];

// Third-party hosts whose (versioned, immutable) files are safe to cache-first
const CACHE_FIRST_HOSTS = [
  'cdn.jsdelivr.net', 'unpkg.com', 'storage.googleapis.com',
  'tfhub.dev', 'www.kaggle.com', 'fonts.googleapis.com', 'fonts.gstatic.com',
];
// Never cache live data
const BYPASS_HOSTS = ['nominatim.openstreetmap.org', 'router.project-osrm.org'];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(PRECACHE))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', event => {
  const { request } = event;
  if (request.method !== 'GET') return;

  const url = new URL(request.url);
  if (url.pathname.includes('/api/')) return;
  if (BYPASS_HOSTS.includes(url.hostname)) return;
  // Map tiles: let the browser handle them
  if (url.hostname.endsWith('tile.openstreetmap.org')) return;

  // Third-party libraries / model files: cache-first
  if (CACHE_FIRST_HOSTS.includes(url.hostname)) {
    event.respondWith(
      caches.match(request).then(hit => hit || fetch(request).then(res => {
        if (res && (res.ok || res.type === 'opaque')) {
          const copy = res.clone();
          caches.open(CACHE_NAME).then(c => c.put(request, copy));
        }
        return res;
      }))
    );
    return;
  }

  // Same-origin app files: network-first, fall back to cache
  if (url.origin === self.location.origin) {
    event.respondWith(
      fetch(request)
        .then(res => {
          if (res && res.status === 200 && res.type === 'basic') {
            const copy = res.clone();
            caches.open(CACHE_NAME).then(c => c.put(request, copy));
          }
          return res;
        })
        .catch(async () => {
          const cached = await caches.match(request, { ignoreSearch: true });
          if (cached) return cached;
          if (request.mode === 'navigate') return caches.match('index.html');
          return new Response('Offline', { status: 503 });
        })
    );
  }
});

self.addEventListener('push', event => {
  let data = {};
  try { data = event.data ? event.data.json() : {}; } catch (e) {}
  event.waitUntil(
    self.registration.showNotification(data.title || 'AccessLens', {
      body: data.body || 'Check the app for updates.',
      icon: 'icons/icon-192.png',
      badge: 'icons/icon-192.png',
      vibrate: [200, 100, 200],
      tag: 'accesslens-push',
    })
  );
});
