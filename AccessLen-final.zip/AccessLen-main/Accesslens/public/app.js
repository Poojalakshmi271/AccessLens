/* =====================================================================
   ACCESSLENS – app.js  (v6 – Complete)
   Path-Zone Detection · Reference-Height Distance Estimation · Free-Space
   State Machine: IDLE → FORWARD → OBSTACLE → SCAN_L → SCAN_R → DECIDING → COOLDOWN
   Features: SOS w/ GPS + Twilio · Voice Commands · High Contrast · Large Text · Night Dim
             Detection History (Export CSV/JSON) · Torch Toggle · Stop Navigation · Speak All
             Emergency Contact Modal · Haptic Feedback · Compass Heading
             Alert Beeps (Web Audio) · Battery + Offline Monitoring
             Onboarding Modal · Feedback Modal · Indoor Mode · Server Sync
   ===================================================================== */
'use strict';

/* ──────────────────────────────────────────────────────────────────
   WEB AUDIO API – Alert beep system
   ──────────────────────────────────────────────────────────────── */
let _audioCtx = null;
function getAudioCtx() {
  if (!_audioCtx) {
    try { _audioCtx = new (window.AudioContext || window.webkitAudioContext)(); } catch(e) {}
  }
  return _audioCtx;
}

/**
 * Play an alert beep. Types: 'obstacle' (urgent), 'warning' (moderate), 'clear' (safe).
 * Respects the alert sounds toggle in settings.
 */
function playBeep(type = 'warning') {
  if (!loadSetting('alerts', true)) return;
  const ctx = getAudioCtx();
  if (!ctx) return;
  // Resume context if suspended (browser autoplay policy)
  if (ctx.state === 'suspended') ctx.resume();

  const configs = {
    obstacle: [{ f: 880, d: 0.12, v: 0.4 }, { f: 660, d: 0.18, v: 0.5 }, { f: 880, d: 0.12, v: 0.4 }],
    warning:  [{ f: 660, d: 0.15, v: 0.3 }, { f: 550, d: 0.20, v: 0.35 }],
    clear:    [{ f: 440, d: 0.10, v: 0.2 }, { f: 660, d: 0.14, v: 0.25 }],
    sos:      [{ f: 1200, d: 0.20, v: 0.5 }, { f: 800, d: 0.20, v: 0.5 }, { f: 1200, d: 0.20, v: 0.5 }],
  };
  const tones = configs[type] || configs.warning;

  let startTime = ctx.currentTime + 0.02;
  tones.forEach(({ f, d, v }) => {
    const osc  = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain); gain.connect(ctx.destination);
    osc.type      = type === 'obstacle' ? 'square' : 'sine';
    osc.frequency.setValueAtTime(f, startTime);
    gain.gain.setValueAtTime(v, startTime);
    gain.gain.exponentialRampToValueAtTime(0.001, startTime + d);
    osc.start(startTime);
    osc.stop(startTime + d + 0.01);
    startTime += d + 0.06;
  });
}

// ── Risk classification ────────────────────────────
const RISK = {
  high:   ['person','car','truck','bus','motorcycle','bicycle',
           'traffic light','stop sign','fire hydrant','train'],
  medium: ['chair','couch','bed','dining table','toilet',
           'suitcase','backpack','skateboard','sports ball'],
  low:    ['potted plant','bottle','cup','book','laptop',
           'remote','keyboard','cell phone','clock','vase'],
};
const RISK_COLORS = { high: '#ff4444', medium: '#ffaa00', low: '#00cc66' };
const OBSTACLE_CLASSES = new Set([...RISK.high, ...RISK.medium]);

function riskOf(label) {
  if (RISK.high.includes(label))   return 'high';
  if (RISK.medium.includes(label)) return 'medium';
  return 'low';
}
function capitalise(s) { return s.charAt(0).toUpperCase() + s.slice(1); }

// ── Per-class reference heights (metres) ──────────
const REAL_HEIGHT_M = {
  person:         1.70,
  car:            1.50,
  truck:          3.00,
  bus:            3.20,
  motorcycle:     1.10,
  bicycle:        1.00,
  'traffic light':0.90,
  'stop sign':    0.75,
  'fire hydrant': 0.65,
  train:          3.80,
  chair:          0.85,
  couch:          0.80,
  bed:            0.55,
  'dining table': 0.75,
  toilet:         0.70,
  suitcase:       0.65,
  backpack:       0.50,
  skateboard:     0.15,
  'sports ball':  0.22,
  _default:       0.60,
};

const FOV_FACTOR = 0.866;

function estimateDistance(bbox, label, frameH) {
  const bboxH    = bbox[3];
  if (bboxH <= 0) return 999;
  const realH    = REAL_HEIGHT_M[label] ?? REAL_HEIGHT_M._default;
  const focalPx  = frameH * FOV_FACTOR;
  const dist     = (realH * focalPx) / bboxH;
  return Math.round(dist * 10) / 10;
}

const MAX_ALERT_DIST = 2.0;
const CONFIDENCE_HIGH = 0.45;
const CONFIDENCE_MED  = 0.55;
const SCAN_DURATION = 6000;
const COOLDOWN_MS   = 10000;

const PATH_ZONE = {
  topY    : 0.30,
  topLeft : 0.375,
  topRight: 0.625,
  botY    : 1.00,
  botLeft : 0.20,
  botRight: 0.80,
};

function isInPathZone(bbox, vW, vH) {
  const [x, y, w, h] = bbox;
  const cx = (x + w / 2) / vW;
  const by = (y + h)     / vH;
  if (by < PATH_ZONE.topY) return false;
  const t     = Math.min(Math.max((by - PATH_ZONE.topY) / (PATH_ZONE.botY - PATH_ZONE.topY), 0), 1);
  const leftX  = PATH_ZONE.topLeft  + t * (PATH_ZONE.botLeft  - PATH_ZONE.topLeft);
  const rightX = PATH_ZONE.topRight + t * (PATH_ZONE.botRight - PATH_ZONE.topRight);
  return cx >= leftX && cx <= rightX;
}

function pathObstacles(predictions, vW, vH) {
  return predictions
    .filter(p => {
      if (!OBSTACLE_CLASSES.has(p.class)) return false;
      const minConf = RISK.high.includes(p.class) ? CONFIDENCE_HIGH : CONFIDENCE_MED;
      if (p.score < minConf) return false;
      if (!isInPathZone(p.bbox, vW, vH)) return false;
      const dist = (p.track && p.track.confirmed)
        ? Math.round(p.track.dist * 10) / 10          // Kalman-smoothed
        : estimateDistance(p.bbox, p.class, vH);      // raw fallback
      p.estDist = dist;
      return dist <= MAX_ALERT_DIST;
    })
    .sort((a, b) => a.estDist - b.estDist);
}

// ── Free-Space Analysis ───────────────────────────
let scanArea = { left: 0, right: 0, frames: 0 };

function accumulateScanData(predictions, side, vW, vH) {
  const frameArea = vW * vH;
  predictions.forEach(p => {
    if (!OBSTACLE_CLASSES.has(p.class) || p.score < 0.38) return;
    const dist     = estimateDistance(p.bbox, p.class, vH);
    const weight   = Math.max(0.1, 1 - dist / 5);
    const areaNorm = (p.bbox[2] * p.bbox[3]) / frameArea;
    scanArea[side] += areaNorm * weight;
  });
  scanArea.frames++;
}

// ── Detection State Machine ────────────────────────
const STATE = {
  IDLE:     'idle',
  FORWARD:  'forward',
  OBSTACLE: 'obstacle',
  SCAN_L:   'scan_left',
  SCAN_R:   'scan_right',
  DECIDING: 'deciding',
  COOLDOWN: 'cooldown',
};
let detState    = STATE.IDLE;
let cocoModel   = null;
let animFrameId = null;
let stateTimer  = null;
let cameraStream = null;
let vidW = 640, vidH = 480;
let latestPredictions = [];

// ── Tracking / performance (logic lives in cv.js) ──
const CV       = window.AccessLensCV;
const tracker  = new CV.ObjectTracker();
const perf     = new CV.PerfMonitor();
const session  = new CV.SessionRecorder();
let latestTracks   = [];
let modelLoadMs    = null;
let targetFps      = 0;        // 0 = as fast as possible
let lastDetectAt   = 0;
let backendSwitching = false;
let lastPerfStats  = { fps: 0, meanMs: 0, p50Ms: 0, p95Ms: 0, frames: 0 };
let lastPerfUiAt   = 0;
let approachHoldUntil = 0;
const benchResults = [];
const TTC_ALERT_S     = 3.0;   // warn when an in-path object would reach you within this time
const TTC_REALERT_MS  = 8000;  // …but not more often than this per tracked object
const ttcAlertedAt    = new Map();

// ── Detection History Ring Buffer ─────────────────
const DET_HISTORY_MAX = 20;
let detHistory = [];

function addToHistory(label, dist, risk) {
  const ts = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  detHistory.unshift({ label, dist, risk, ts });
  if (detHistory.length > DET_HISTORY_MAX) detHistory.pop();
  renderDetHistory();
}

function renderDetHistory() {
  const ul = document.getElementById('det-history-list');
  if (!ul) return;
  if (detHistory.length === 0) {
    ul.innerHTML = '<li class="hist-empty">No detections yet</li>';
    return;
  }
  ul.innerHTML = detHistory.map(e => `
    <li class="hist-item hist-${e.risk}">
      <span class="hist-ts">${e.ts}</span>
      <span class="hist-label">${capitalise(e.label)}</span>
      <span class="hist-dist">${e.dist < 50 ? e.dist + 'm' : '>50m'}</span>
      <span class="hist-badge ${e.risk}">${capitalise(e.risk)}</span>
    </li>
  `).join('');
}

function toggleDetHistory() {
  const panel = document.getElementById('det-history-panel');
  if (!panel) return;
  panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
  if (panel.style.display === 'block') renderDetHistory();
}

function clearDetHistory() {
  detHistory = [];
  renderDetHistory();
  showToast('🗑 Detection log cleared');
}

// ── Canvas Drawing ─────────────────────────────────
function resizeCanvas(canvas) {
  const vp  = canvas.parentElement;
  const dpr = window.devicePixelRatio || 1;
  canvas.width  = vp.clientWidth  * dpr;
  canvas.height = vp.clientHeight * dpr;
  canvas.style.width  = vp.clientWidth  + 'px';
  canvas.style.height = vp.clientHeight + 'px';
  return { dpr, cW: vp.clientWidth, cH: vp.clientHeight };
}

function drawScene(canvas, predictions) {
  const { dpr, cW, cH } = resizeCanvas(canvas);
  const ctx = canvas.getContext('2d');
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.scale(dpr, dpr);

  const sx = cW / (vidW || 640);
  const sy = cH / (vidH || 480);

  // ── Draw path-zone trapezoid ──────────────────────
  ctx.save();
  const pz = PATH_ZONE;
  ctx.beginPath();
  ctx.moveTo(pz.topLeft  * cW, pz.topY * cH);
  ctx.lineTo(pz.topRight * cW, pz.topY * cH);
  ctx.lineTo(pz.botRight * cW, pz.botY * cH);
  ctx.lineTo(pz.botLeft  * cW, pz.botY * cH);
  ctx.closePath();
  ctx.fillStyle   = 'rgba(0,255,136,0.05)';
  ctx.strokeStyle = 'rgba(0,255,136,0.50)';
  ctx.lineWidth   = 1.5;
  ctx.setLineDash([8, 5]);
  ctx.fill();
  ctx.stroke();
  ctx.setLineDash([]);
  ctx.fillStyle = 'rgba(0,255,136,0.72)';
  ctx.font = '600 11px Inter, sans-serif';
  ctx.fillText('SAFE PATH', pz.topLeft * cW + 4, pz.topY * cH - 5);
  ctx.restore();

  // ── Draw bounding boxes ───────────────────────────
  predictions.forEach(pred => {
    const [x, y, w, h] = pred.bbox;
    const tr        = pred.track && pred.track.confirmed ? pred.track : null;
    const dist      = tr ? Math.round(tr.dist * 10) / 10 : estimateDistance(pred.bbox, pred.class, vidH);
    const inZone    = isInPathZone(pred.bbox, vidW, vidH);
    const minConf   = RISK.high.includes(pred.class) ? CONFIDENCE_HIGH : CONFIDENCE_MED;
    const isObstacle = OBSTACLE_CLASSES.has(pred.class)
                    && inZone
                    && dist <= MAX_ALERT_DIST
                    && pred.score >= minConf;
    const risk  = riskOf(pred.class);
    const color = isObstacle ? RISK_COLORS[risk] : 'rgba(100,160,255,0.45)';

    const px = x * sx, py = y * sy, pw = w * sx, ph = h * sy;

    ctx.save();
    ctx.shadowColor = color;
    ctx.shadowBlur  = isObstacle ? 16 : 3;
    ctx.strokeStyle = color;
    ctx.lineWidth   = isObstacle ? 2.5 : 1;
    if (!isObstacle) ctx.setLineDash([4, 4]);
    ctx.strokeRect(px, py, pw, ph);
    ctx.setLineDash([]);

    if (isObstacle) {
      const cs = 10; ctx.lineWidth = 3;
      [[px,py,1,1],[px+pw,py,-1,1],[px,py+ph,1,-1],[px+pw,py+ph,-1,-1]].forEach(([bx,by,dx,dy])=>{
        ctx.beginPath();
        ctx.moveTo(bx+dx*cs,by);ctx.lineTo(bx,by);ctx.lineTo(bx,by+dy*cs);
        ctx.stroke();
      });
    }
    ctx.shadowBlur = 0;

    let distStr    = dist < 50 ? `${dist}m` : '';
    if (tr && tr.ttc != null && tr.ttc <= 10) distStr += ` ⏱${tr.ttc.toFixed(1)}s`;
    const mainTxt  = capitalise(pred.class) + (tr ? ` #${tr.id}` : '');
    const fs = Math.max(10, Math.min(13, pw / 5));
    ctx.font = `${isObstacle ? '700' : '500'} ${fs}px Inter, sans-serif`;

    if (isObstacle) {
      const nameTxt = mainTxt;
      const distLabel = distStr;
      const nW = ctx.measureText(nameTxt).width;
      const dW = ctx.measureText(distLabel).width;
      const pad = 5, gap = 6;
      const totalW = nW + gap + dW + pad * 2;
      const lh  = fs + pad * 2;
      const ly  = py - lh < 0 ? py + 2 : py - lh;

      ctx.fillStyle = color;
      ctx.beginPath(); ctx.roundRect(px, ly, totalW, lh, 4); ctx.fill();

      const distBg = risk === 'high' ? 'rgba(120,0,0,0.85)' : 'rgba(80,50,0,0.85)';
      ctx.fillStyle = distBg;
      ctx.beginPath(); ctx.roundRect(px + pad + nW + gap - 2, ly + 2, dW + 4, lh - 4, 3); ctx.fill();

      ctx.fillStyle = risk === 'high' ? '#fff' : '#000';
      ctx.fillText(nameTxt,  px + pad, ly + fs + pad * 0.5);
      ctx.fillStyle = '#fff';
      ctx.font = `800 ${fs}px Inter, sans-serif`;
      ctx.fillText(distLabel, px + pad + nW + gap, ly + fs + pad * 0.5);
    } else {
      const txt = distStr ? `${mainTxt} ${distStr}` : mainTxt;
      const tw  = ctx.measureText(txt).width;
      const pad = 3, lh = fs + pad * 2;
      const ly  = py - lh < 0 ? py + 1 : py - lh;
      ctx.fillStyle = 'rgba(80,120,180,0.6)';
      ctx.beginPath(); ctx.roundRect(px, ly, tw + pad*2, lh, 3); ctx.fill();
      ctx.fillStyle = 'rgba(200,220,255,0.9)';
      ctx.font = `500 ${fs}px Inter, sans-serif`;
      ctx.fillText(txt, px + pad, ly + fs + pad * 0.5);
    }
    ctx.restore();
  });

  // ── Scan half-shading ─────────────────────────────
  if (detState === STATE.SCAN_L || detState === STATE.SCAN_R) {
    const half = cW / 2;
    ctx.save();
    ctx.fillStyle = detState === STATE.SCAN_L ? 'rgba(0,180,255,0.07)' : 'rgba(0,255,136,0.07)';
    if (detState === STATE.SCAN_L) ctx.fillRect(0, 0, half, cH);
    else ctx.fillRect(half, 0, half, cH);
    ctx.restore();
  }
}

// ── UI Helpers ─────────────────────────────────────
function setDetState(icon, msg) {
  const el = document.getElementById('det-state-msg');
  const ic = document.getElementById('det-state-icon');
  if (el) el.textContent = msg;
  if (ic) ic.textContent = icon;
}
function setWarnBanner(text, danger = true) {
  const b = document.getElementById('warn-banner');
  const t = b?.querySelector('.warn-text');
  if (!t) return;
  t.textContent    = text;
  b.style.background = danger
    ? 'linear-gradient(135deg,rgba(255,60,60,.95),rgba(200,20,20,.9))'
    : 'linear-gradient(135deg,rgba(0,180,80,.95),rgba(0,140,60,.9))';
}
function setDirection(dir) {
  const el = document.getElementById('direction-text');
  if (el) { el.style.opacity='0'; setTimeout(()=>{ el.textContent=dir; el.style.opacity='1'; el.style.transition='opacity 0.3s'; },150); }
  ['left','center','right'].forEach(a => document.getElementById('arr-'+a)?.classList.remove('active-arr'));
  const map = {'Move Left':'left','Move Right':'right','Move Forward':'center','Stop':'center'};
  document.getElementById('arr-'+(map[dir]||'center'))?.classList.add('active-arr');
}
function showScanInstruction(side) {
  const el = document.getElementById('scan-instruction');
  const ar = document.getElementById('scan-arrow');
  const lb = document.getElementById('scan-label');
  const fi = document.getElementById('scan-timer-fill');
  if (!el) return;
  el.style.display = 'flex';
  if (ar) ar.textContent = side === 'left' ? '◀' : '▶';
  if (lb) lb.textContent = `Slowly show camera to the ${side.toUpperCase()}`;
  if (fi) {
    fi.style.transition = 'none'; fi.style.transform = 'scaleX(1)';
    requestAnimationFrame(() => {
      fi.style.transition = `transform ${SCAN_DURATION}ms linear`;
      fi.style.transform  = 'scaleX(0)';
    });
  }
}
function hideScanInstruction() {
  const el = document.getElementById('scan-instruction');
  if (el) el.style.display = 'none';
}

// ── Haptic Feedback ────────────────────────────────
function vibrate(pattern) {
  if (!loadSetting('haptic', true)) return;
  if (navigator.vibrate) navigator.vibrate(pattern);
}

// ── State Machine ──────────────────────────────────
function transitionTo(newState, obstacles = []) {
  clearTimeout(stateTimer);
  detState = newState;

  switch (newState) {

    case STATE.FORWARD:
      hideScanInstruction();
      setDetState('✅', 'Scanning path – move forward');
      setWarnBanner('✓ Path Clear – Move Forward', false);
      setDirection('Move Forward');
      break;

    case STATE.OBSTACLE: {
      const top   = obstacles[0];
      const name  = top ? capitalise(top.class) : 'Obstacle';
      const dStr  = top?.estDist != null ? ` at ${top.estDist}m` : '';
      const risk  = top ? riskOf(top.class) : 'medium';
      setDetState('⚠', `${name}${dStr} in your path!`);
      setWarnBanner(`⚠ ${name}${dStr} – Stop!`, true);
      setDirection('Stop');
      speak(`${name} detected${dStr} in your path. Please stop. Checking left and right for a safe route.`);
      showToast(`⚠ ${name}${dStr}`);
      // Play alert beep based on risk level
      playBeep(risk === 'high' ? 'obstacle' : 'warning');
      vibrate([200, 100, 200, 100, 400]);
      // Add to history
      addToHistory(name, top?.estDist ?? 99, risk);
      // Log to server
      logDetectionToServer(name, top?.estDist ?? 99, risk);
      // Update header status
      setHeaderBadge('hdr-ai', '🤖', 'active');
      stateTimer = setTimeout(() => transitionTo(STATE.SCAN_L), 1800);
      break;
    }

    case STATE.SCAN_L:
      scanArea = { left: 0, right: 0, frames: 0 };
      showScanInstruction('left');
      setDetState('◀', 'Scanning LEFT side for free space…');
      speak('Please slowly turn the camera to the left. Scanning for clear space.');
      stateTimer = setTimeout(() => transitionTo(STATE.SCAN_R), SCAN_DURATION);
      break;

    case STATE.SCAN_R:
      showScanInstruction('right');
      setDetState('▶', 'Now scanning RIGHT side…');
      speak('Good. Now slowly turn the camera to the right. Scanning for clear space.');
      stateTimer = setTimeout(() => transitionTo(STATE.DECIDING), SCAN_DURATION);
      break;

    case STATE.DECIDING:
      hideScanInstruction();
      decidePath();
      break;

    case STATE.COOLDOWN:
      stateTimer = setTimeout(() => transitionTo(STATE.FORWARD), COOLDOWN_MS);
      break;
  }
}

function decidePath() {
  const lArea = scanArea.left;
  const rArea = scanArea.right;
  const frames = Math.max(scanArea.frames, 1);
  const lCoverage = lArea / frames;
  const rCoverage = rArea / frames;

  let direction, voiceMsg, bannerMsg;

  if (lCoverage === 0 && rCoverage === 0) {
    direction  = 'Move Forward';
    bannerMsg  = '✓ Both sides clear – Move Forward';
    voiceMsg   = 'Both sides are clear. You can move forward safely.';
  } else if (lCoverage === 0) {
    direction  = 'Move Left';
    bannerMsg  = '◀ Left is clear – Move Left';
    voiceMsg   = 'The left side is completely clear. Please move to the left.';
  } else if (rCoverage === 0) {
    direction  = 'Move Right';
    bannerMsg  = '▶ Right is clear – Move Right';
    voiceMsg   = 'The right side is completely clear. Please move to the right.';
  } else if (lCoverage < rCoverage) {
    const pct  = Math.round((1 - lCoverage / rCoverage) * 100);
    direction  = 'Move Left';
    bannerMsg  = `◀ Left has ${pct}% more free space – Move Left`;
    voiceMsg   = `The left side has ${pct} percent more free space. Please move left.`;
  } else if (rCoverage < lCoverage) {
    const pct  = Math.round((1 - rCoverage / lCoverage) * 100);
    direction  = 'Move Right';
    bannerMsg  = `▶ Right has ${pct}% more free space – Move Right`;
    voiceMsg   = `The right side has ${pct} percent more free space. Please move right.`;
  } else {
    direction  = 'Move Left';
    bannerMsg  = '◀ Similar obstacles – Try Left';
    voiceMsg   = 'Both sides have similar obstacles. Try moving slightly to the left.';
  }

  // Update Smart Assist recommended path
  updateRecommendedPath(direction);

  detState = STATE.COOLDOWN;
  setDetState('🧭', bannerMsg);
  setWarnBanner('✓ ' + bannerMsg, false);
  setDirection(direction);
  speak(voiceMsg);
  showToast(`🧭 ${direction}`);
  playBeep('clear');
  vibrate([100, 50, 100]);
  setTimeout(() => speak(voiceMsg), 2500);
  stateTimer = setTimeout(() => transitionTo(STATE.FORWARD), COOLDOWN_MS);
}

// ── Manual Scan Trigger ────────────────────────────
function triggerManualScan() {
  if (detState === STATE.FORWARD || detState === STATE.COOLDOWN || detState === STATE.IDLE) {
    speak('Starting manual environment scan.');
    transitionTo(STATE.SCAN_L);
    showToast('🔍 Manual scan started');
  } else {
    showToast('⚠ Scan already in progress');
  }
}

// ── Torch / Flashlight Toggle ──────────────────────
let torchOn = false;
async function toggleTorch() {
  if (!cameraStream) { showToast('⚠ Camera not active'); return; }
  const track = cameraStream.getVideoTracks()[0];
  if (!track) return;
  try {
    torchOn = !torchOn;
    await track.applyConstraints({ advanced: [{ torch: torchOn }] });
    const btn = document.getElementById('torch-btn');
    if (btn) {
      btn.textContent = torchOn ? '💡' : '🔦';
      btn.classList.toggle('torch-active', torchOn);
    }
    showToast(torchOn ? '💡 Torch ON' : '🔦 Torch OFF');
  } catch(e) {
    showToast('⚠ Torch not supported on this device');
    torchOn = false;
  }
}

// ── Snapshot Capture ───────────────────────────────
function captureSnapshot() {
  const video  = document.getElementById('camera-video');
  const canvas = document.getElementById('det-canvas');
  if (!video || video.readyState < 2) { showToast('⚠ Camera not ready'); return; }
  // Composite video + canvas overlay
  const snap = document.createElement('canvas');
  snap.width  = video.videoWidth;
  snap.height = video.videoHeight;
  const ctx = snap.getContext('2d');
  ctx.drawImage(video, 0, 0, snap.width, snap.height);
  // Draw detection boxes from current canvas
  ctx.drawImage(canvas, 0, 0, snap.width, snap.height);
  snap.toBlob(blob => {
    if (!blob) { showToast('⚠ Snapshot failed'); return; }
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `accesslens-${Date.now()}.png`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('📸 Snapshot saved!');
    vibrate([50, 50, 50]);
  }, 'image/png');
}

// ── COCO-SSD Detection Loop ────────────────────────
async function runDetectionLoop() {
  const video  = document.getElementById('camera-video');
  const canvas = document.getElementById('det-canvas');
  if (!video || !canvas || !cocoModel) return;
  if (video.readyState < 2 || backendSwitching) {
    animFrameId = requestAnimationFrame(runDetectionLoop); return;
  }

  // Optional frame-rate cap (saves battery / heat on weak phones)
  const tNow = performance.now();
  if (targetFps > 0 && tNow - lastDetectAt < 1000 / targetFps) {
    animFrameId = requestAnimationFrame(runDetectionLoop); return;
  }
  lastDetectAt = tNow;

  vidW = video.videoWidth  || 640;
  vidH = video.videoHeight || 480;

  let predictions = [];
  const t0 = performance.now();
  try { predictions = await cocoModel.detect(video); } catch(e) {
    animFrameId = requestAnimationFrame(runDetectionLoop); return;
  }
  const t1 = performance.now();
  perf.recordFrame(t1 - t0, t1);
  latestPredictions = predictions;

  // ── Multi-object tracking: stable IDs, smoothed distance, closing speed, TTC ──
  const dets = predictions.map(p => ({
    bbox: p.bbox, label: p.class, score: p.score,
    dist: Math.min(estimateDistance(p.bbox, p.class, vidH), 60),
  }));
  latestTracks = tracker.update(dets, t1);
  for (const t of latestTracks) {
    if (t.detIndex < 0) continue;
    predictions[t.detIndex].track = t;
    if (t.confirmed) {
      session.maybeAdd(t, {
        inPath: isInPathZone(t.bbox, vidW, vidH), risk: riskOf(t.label), fps: lastPerfStats.fps,
      }, t1);
    }
  }
  updatePerfPanel();

  drawScene(canvas, predictions);

  const inPath = pathObstacles(predictions, vidW, vidH);
  const countEl = document.querySelector('.obj-counts span');
  if (countEl) {
    countEl.textContent = inPath.length > 0
      ? `⚠ ${inPath.length} obstacle${inPath.length>1?'s':''} in path (${predictions.length} total)`
      : `✓ ${predictions.length} object${predictions.length!==1?'s':''} – path clear`;
  }

  if (detState === STATE.SCAN_L) {
    accumulateScanData(predictions, 'left', vidW, vidH);
  } else if (detState === STATE.SCAN_R) {
    accumulateScanData(predictions, 'right', vidW, vidH);
  }

  if (detState === STATE.FORWARD) {
    if (inPath.length > 0) {
      transitionTo(STATE.OBSTACLE, inPath);
    } else if (checkApproachAlerts(t1)) {
      approachHoldUntil = t1 + 2500;
    } else if (t1 < approachHoldUntil) {
      // keep the approach warning on screen briefly
    } else {
      const nearest = predictions
        .map(p => ({ ...p, d: estimateDistance(p.bbox, p.class, vidH) }))
        .sort((a,b) => a.d - b.d)[0];
      const nearStr = nearest && nearest.d < 50
        ? ` · nearest: ${nearest.class} ${nearest.d}m`
        : '';
      setDetState('✅', `Path clear${nearStr}`);
    }
  }

  // Update Smart Assist with live data
  renderSmartAssist(predictions, vidH);

  animFrameId = requestAnimationFrame(runDetectionLoop);
}

// ── Approaching-object warning (uses tracker time-to-collision) ──
function checkApproachAlerts(now) {
  let worst = null;
  for (const t of latestTracks) {
    if (!t.confirmed || t.detIndex < 0 || t.ttc == null || t.ttc > TTC_ALERT_S) continue;
    if (!OBSTACLE_CLASSES.has(t.label)) continue;
    if (!isInPathZone(t.bbox, vidW, vidH)) continue;
    if (now - (ttcAlertedAt.get(t.id) || -Infinity) < TTC_REALERT_MS) continue;
    if (!worst || t.ttc < worst.ttc) worst = t;
  }
  if (!worst) return false;
  ttcAlertedAt.set(worst.id, now);
  const secs = Math.max(1, Math.round(worst.ttc));
  const name = capitalise(worst.label);
  speak(`${name} approaching, about ${secs} second${secs > 1 ? 's' : ''} away. Stop.`);
  setDetState('⚠', `${name} approaching – ${worst.ttc.toFixed(1)}s`);
  setWarnBanner(`⚠ ${name} approaching – ~${secs}s`, true);
  playBeep(riskOf(worst.label) === 'high' ? 'obstacle' : 'warning');
  vibrate([150, 80, 150]);
  addToHistory(name, Math.round(worst.dist * 10) / 10, riskOf(worst.label));
  return true;
}

// ── Performance panel ─────────────────────────────
function updatePerfPanel(force = false) {
  const now = performance.now();
  if (!force && now - lastPerfUiAt < 500) return;
  lastPerfUiAt = now;
  lastPerfStats = perf.stats();

  const panel = document.getElementById('perf-panel');
  if (!panel || panel.style.display === 'none') return;
  const set = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
  set('perf-fps',   lastPerfStats.frames ? lastPerfStats.fps.toFixed(1) : '–');
  set('perf-ms',    lastPerfStats.frames ? lastPerfStats.meanMs.toFixed(0) + ' ms' : '–');
  set('perf-p95',   lastPerfStats.frames ? lastPerfStats.p95Ms.toFixed(0) + ' ms' : '–');
  set('perf-backend', (window.tf && tf.getBackend && tf.getBackend()) || '–');
  set('perf-res',   cocoModel ? `${vidW}×${vidH}` : '–');
  set('perf-load',  modelLoadMs != null ? (modelLoadMs / 1000).toFixed(1) + ' s' : '–');
  set('perf-tracks', String(latestTracks.filter(t => t.confirmed).length));
  set('perf-rows',  String(session.rows.length));
  const bar = document.getElementById('bench-progress');
  if (bar) bar.style.transform = `scaleX(${perf.benchmarking ? perf.benchmarkProgress(now) : 0})`;
}

function togglePerfPanel() {
  const panel = document.getElementById('perf-panel');
  if (!panel) return;
  const open = panel.style.display === 'none';
  panel.style.display = open ? 'block' : 'none';
  document.getElementById('perf-toggle-btn')?.setAttribute('aria-expanded', String(open));
  if (open) { updatePerfPanel(true); renderBench(); }
}

function setTargetFps(v) {
  targetFps = Number(v) || 0;
  showToast(targetFps ? `Detection capped at ${targetFps} FPS` : 'Detection uncapped');
}

async function setTfBackend(name) {
  if (!window.tf) return;
  if (backendSwitching) return;
  backendSwitching = true;
  showToast(`Switching to ${name}…`);
  try {
    const ok = await tf.setBackend(name);
    await tf.ready();
    if (!ok) throw new Error('backend unavailable');
    if (cocoModel) {                       // reload weights on the new backend
      const tLoad = performance.now();
      const fresh = await cocoSsd.load({ base: 'lite_mobilenet_v2' });
      modelLoadMs = performance.now() - tLoad;
      try { cocoModel.dispose && cocoModel.dispose(); } catch (e) {}
      cocoModel = fresh;
    }
    showToast(`✓ Backend: ${tf.getBackend()}`);
  } catch (e) {
    console.warn('Backend switch failed:', e);
    showToast('⚠ Could not switch backend');
    const sel = document.getElementById('backend-select');
    if (sel && tf.getBackend) sel.value = tf.getBackend();
  } finally {
    backendSwitching = false;
    updatePerfPanel(true);
  }
}

// ── 10-second benchmark ───────────────────────────
function runBenchmark() {
  if (!cocoModel || !cameraStream) { showToast('⚠ Start the camera first (Detection screen)'); return; }
  if (perf.benchmarking) return;
  const btn = document.getElementById('bench-btn');
  if (btn) btn.disabled = true;
  perf.onBenchmarkDone = result => {
    benchResults.push(result);
    if (btn) btn.disabled = false;
    renderBench();
    showToast(`✓ Benchmark: ${result.fps} FPS, ${result.meanMs} ms/frame`);
    speak(`Benchmark finished. ${Math.round(result.fps)} frames per second.`);
  };
  perf.startBenchmark(10000, {
    model: 'coco-ssd lite_mobilenet_v2',
    backend: (window.tf && tf.getBackend && tf.getBackend()) || 'unknown',
    inputRes: `${vidW}x${vidH}`,
    fpsCap: targetFps || 'none',
    modelLoadS: modelLoadMs != null ? +(modelLoadMs / 1000).toFixed(2) : null,
    cores: navigator.hardwareConcurrency || null,
    deviceMemoryGB: navigator.deviceMemory || null,
    userAgent: navigator.userAgent,
    date: new Date().toISOString(),
  }, performance.now());
  showToast('⏱ Benchmark running for 10 s – point the camera at a normal scene');
}

function renderBench() {
  const ul = document.getElementById('bench-results');
  if (!ul) return;
  if (!benchResults.length) { ul.innerHTML = '<li class="hist-empty">No benchmark run yet</li>'; return; }
  ul.innerHTML = benchResults.map((r, i) => `
    <li class="bench-row">
      <span>#${i + 1} ${r.backend} · ${r.inputRes}${r.fpsCap !== 'none' ? ' · cap ' + r.fpsCap : ''}</span>
      <span><b>${r.fps}</b> FPS · ${r.meanMs} ms · p95 ${r.p95Ms} ms</span>
    </li>`).join('');
}

function downloadText(filename, text, mime) {
  const blob = new Blob([text], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function exportBenchmark() {
  if (!benchResults.length) { showToast('⚠ Run a benchmark first'); return; }
  downloadText(`accesslens-benchmark-${Date.now()}.json`, JSON.stringify(benchResults, null, 2), 'application/json');
  showToast('📥 Benchmark exported');
}

function exportSessionData() {
  if (!session.rows.length) { showToast('⚠ No tracking data yet – run detection first'); return; }
  downloadText(`accesslens-session-${Date.now()}.csv`, session.toCSV(), 'text/csv');
  showToast(`📥 Exported ${session.rows.length} tracking rows`);
}

function clearSessionData() {
  session.clear();
  updatePerfPanel(true);
  showToast('🗑 Tracking data cleared');
}

// ── Dynamic Smart Assist Rendering ────────────────
function renderSmartAssist(predictions, frameH) {
  const listEl = document.getElementById('assist-objects-list') || document.querySelector('.objects-list');
  if (!listEl) return;

  listEl.innerHTML = '';

  if (predictions.length === 0) {
    listEl.innerHTML = '<li style="padding: 20px; text-align: center; color: var(--clr-text-muted);">No objects detected</li>';
    const pGrid = document.getElementById('assist-priority-grid') || document.querySelector('.priority-grid');
    if (pGrid) pGrid.innerHTML = '<div class="priority-card p-low"><span class="p-num">0</span><span class="p-label">Hazards</span></div>';
    updateAssistConfidence(0, 'forward');
    return;
  }

  let highCount = 0, medCount = 0, lowCount = 0;

  const processed = predictions.map(p => {
    const dist = estimateDistance(p.bbox, p.class, frameH);
    return { ...p, dist };
  }).sort((a, b) => a.dist - b.dist).slice(0, 6);

  processed.forEach(p => {
    const r = riskOf(p.class);
    let riskClass = 'risk-low', badgeClass = 'low', barColor = 'risk-green', barPct = 30;
    const objIcon = getObjIcon(p.class);

    if (r === 'high') {
      highCount++; riskClass = 'risk-high'; badgeClass = 'high'; barColor = 'risk-red';
      barPct = Math.min(100, Math.max(70, 100 - p.dist * 10));
    } else if (r === 'medium') {
      medCount++; riskClass = 'risk-medium'; badgeClass = 'medium'; barColor = 'risk-yellow'; barPct = 50;
    } else {
      lowCount++;
    }

    const li = document.createElement('li');
    li.className = `obj-card ${riskClass}`;
    li.setAttribute('role', 'listitem');
    li.innerHTML = `
      <div class="obj-info">
        <span class="obj-icon" aria-hidden="true">${objIcon}</span>
        <div class="obj-details">
          <span class="obj-name">${capitalise(p.class)}</span>
          <span class="obj-dist">${p.dist < 50 ? p.dist + 'm' : '>50m'} · ${r} risk</span>
        </div>
      </div>
      <div class="obj-risk">
        <span class="risk-badge ${badgeClass}" aria-label="${r} risk">${capitalise(r)}</span>
        <div class="risk-bar-wrap">
          <div class="risk-bar ${barColor}" style="width:${barPct}%"></div>
        </div>
      </div>
    `;
    listEl.appendChild(li);
  });

  // Update Priority Grid
  const pGrid = document.getElementById('assist-priority-grid') || document.querySelector('.priority-grid');
  if (pGrid) {
    pGrid.innerHTML = `
      ${highCount > 0 ? `<div class="priority-card p-high"><span class="p-num">${highCount}</span><span class="p-label">High Risk</span></div>` : ''}
      ${medCount > 0 ? `<div class="priority-card p-medium"><span class="p-num">${medCount}</span><span class="p-label">Medium</span></div>` : ''}
      ${lowCount > 0 ? `<div class="priority-card p-low"><span class="p-num">${lowCount}</span><span class="p-label">Low Risk</span></div>` : ''}
      ${(highCount+medCount+lowCount) === 0 ? `<div class="priority-card p-low"><span class="p-num">0</span><span class="p-label">Hazards</span></div>` : ''}
    `;
  }

  // Compute confidence from scan data or number of clear objects
  const totalObj = predictions.length;
  const obstacleRatio = (highCount + medCount) / Math.max(totalObj, 1);
  const confidence = Math.round((1 - obstacleRatio * 0.7) * 100);
  const recDir = highCount > 0 ? (scanArea.left < scanArea.right ? 'left' : 'right') : 'forward';
  updateAssistConfidence(confidence, recDir);
}

function getObjIcon(cls) {
  const map = {
    person:'🚶', car:'🚗', truck:'🚛', bus:'🚌', motorcycle:'🏍', bicycle:'🚲',
    'traffic light':'🚦', 'stop sign':'🛑', 'fire hydrant':'🔥', train:'🚂',
    chair:'🪑', couch:'🛋', bed:'🛏', 'dining table':'🍽', toilet:'🚽',
    suitcase:'🧳', backpack:'🎒', skateboard:'🛹', 'sports ball':'⚽',
    'potted plant':'🌱', bottle:'🍶', cup:'☕', book:'📖', laptop:'💻',
    remote:'📱', keyboard:'⌨', 'cell phone':'📱', clock:'🕐', vase:'🏺',
  };
  return map[cls] || '🎯';
}

// ── Update Recommended Path in Assist screen ───────
function updateRecommendedPath(direction) {
  const dirs = { 'Move Left': 'left', 'Move Right': 'right', 'Move Forward': 'forward', 'Stop': 'forward' };
  const active = dirs[direction] || 'forward';
  ['left','forward','right'].forEach(d => {
    const el = document.getElementById(`sp-dir-${d}`);
    if (el) {
      el.classList.toggle('active-dir', d === active);
      el.classList.toggle('inactive', d !== active);
    }
  });
}

function updateAssistConfidence(pct, recDir) {
  const fill = document.getElementById('conf-bar-fill');
  const pctEl = document.getElementById('conf-pct');
  const wrap  = document.getElementById('conf-bar-wrap');
  if (fill)  { fill.style.width = pct + '%'; }
  if (pctEl) { pctEl.textContent = pct + '%'; }
  if (wrap)  { wrap.setAttribute('aria-valuenow', pct); }
  updateRecommendedPath(
    recDir === 'left'  ? 'Move Left'  :
    recDir === 'right' ? 'Move Right' : 'Move Forward'
  );
}

// ── Speak All Objects ──────────────────────────────
function speakAllObjects() {
  if (!latestPredictions || latestPredictions.length === 0) {
    speak('No objects currently detected.');
    showToast('No objects to read');
    return;
  }
  const processed = latestPredictions.map(p => {
    const dist = estimateDistance(p.bbox, p.class, vidH);
    return { ...p, dist };
  }).sort((a,b) => a.dist - b.dist).slice(0, 5);

  let msg = `I can see ${processed.length} object${processed.length>1?'s':''}. `;
  processed.forEach((p, i) => {
    msg += `${i+1}. ${capitalise(p.class)} at ${p.dist < 50 ? p.dist + ' meters' : 'far away'}, ${riskOf(p.class)} risk. `;
  });
  speak(msg);
  showToast('🔊 Reading all objects…');
}

// ── Request Rescan ────────────────────────────────
function requestRescan() {
  if (detState === STATE.FORWARD || detState === STATE.COOLDOWN) {
    speak('Rescanning environment.');
    transitionTo(STATE.SCAN_L);
    showToast('🔄 Rescanning…');
  } else {
    showToast('⚠ Please open Detection first');
  }
}

// ── Model Loading ──────────────────────────────────
async function loadModel() {
  setDetState('⏳', 'Loading AI model…');
  setHeaderBadge('hdr-ai', '🤖', 'loading');
  try {
    const tLoad = performance.now();
    cocoModel = await cocoSsd.load({ base: 'lite_mobilenet_v2' });
    modelLoadMs = performance.now() - tLoad;
    tracker.reset();
    updatePerfPanel(true);
    setDetState('✅', 'Scanning path…');
    setHeaderBadge('hdr-ai', '🤖', 'active');
    showToast('🤖 AI ready – watching your path');
    speak('Object detection is active. I will alert you if anything is in your path.');
    transitionTo(STATE.FORWARD);
    runDetectionLoop();
  } catch(e) {
    setDetState('❌', 'Model load failed – check internet');
    setHeaderBadge('hdr-ai', '🤖', 'error');
    console.error(e);
  }
}

// ── Camera ─────────────────────────────────────────
async function startCamera() {
  const video = document.getElementById('camera-video');
  const ph    = document.getElementById('camera-off-placeholder');
  if (!video) return;
  if (cameraStream && cameraStream.active) {
    video.srcObject = cameraStream; video.style.display='block';
    if (ph) ph.style.display='none';
    setHeaderBadge('hdr-cam', '📷', 'active');
    if (!cocoModel) await loadModel();
    else { transitionTo(STATE.FORWARD); runDetectionLoop(); }
    return;
  }
  try {
    cameraStream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode: { ideal: 'environment' }, width:{ideal:1280}, height:{ideal:720} },
      audio: false,
    });
    video.srcObject = cameraStream; video.style.display='block';
    if (ph) ph.style.display='none';
    setHeaderBadge('hdr-cam', '📷', 'active');
    showToast('📷 Camera on');
    await loadModel();
  } catch(e) {
    console.warn('Camera error:', e);
    if (video) video.style.display='none';
    if (ph)    ph.style.display='flex';
    setDetState('🚫','Camera access denied');
    setHeaderBadge('hdr-cam', '📷', 'error');
    showToast('⚠ Camera access denied');
  }
}

function stopCamera() {
  if (animFrameId) { cancelAnimationFrame(animFrameId); animFrameId=null; }
  clearTimeout(stateTimer);
  detState = STATE.IDLE;
  tracker.reset(); ttcAlertedAt.clear(); latestTracks = [];
  if (perf.benchmarking) { perf.cancelBenchmark(); const b = document.getElementById('bench-btn'); if (b) b.disabled = false; }
  torchOn = false;
  const torchBtn = document.getElementById('torch-btn');
  if (torchBtn) { torchBtn.textContent = '🔦'; torchBtn.classList.remove('torch-active'); }
  if (cameraStream) { cameraStream.getTracks().forEach(t=>t.stop()); cameraStream=null; }
  const v=document.getElementById('camera-video');
  if (v) { v.srcObject=null; v.style.display='none'; }
  const ph=document.getElementById('camera-off-placeholder');
  if (ph) ph.style.display='flex';
  hideScanInstruction();
  setHeaderBadge('hdr-cam', '📷', 'inactive');
}

// ── Header Badge Updater ───────────────────────────
function setHeaderBadge(id, icon, state) {
  const el = document.getElementById(id);
  if (!el) return;
  el.textContent = icon;
  el.className = `hdr-badge hdr-${id.replace('hdr-','')} badge-${state}`;
}

// ── Screen Navigation ──────────────────────────────
const screens = document.querySelectorAll('.screen');
const navBtns = document.querySelectorAll('.nav-btn');
function showScreen(id) {
  screens.forEach(s=>s.classList.remove('active'));
  navBtns.forEach(b=>b.classList.toggle('active', b.dataset.screen===id));
  const t=document.getElementById('screen-'+id); if(t) t.classList.add('active');
  window.scrollTo({top:0,behavior:'smooth'});
  if (id==='detection') startCamera(); else stopCamera();
  if (id==='navigation' && typeof Nav !== 'undefined') Nav.onNavScreenEnter();
}

// ── Status Card Cycling ────────────────────────────
const statuses=[
  {text:'Safe path detected',color:'#00ff88',icon:'✓',dotClr:'#00ff88'},
  {text:'Obstacle ahead',    color:'#ffcc00',icon:'⚠',dotClr:'#ffcc00'},
  {text:'Clear path – proceed',color:'#00d4ff',icon:'▶',dotClr:'#00d4ff'},
  {text:'High risk zone!',   color:'#ff4444',icon:'!',dotClr:'#ff4444'},
];
let statusIdx=0;
function cycleStatus(){
  statusIdx=(statusIdx+1)%statuses.length; const s=statuses[statusIdx];
  const txt=document.getElementById('status-text');
  if(txt){txt.textContent=s.text; txt.style.color=s.color;}
  const ico=document.getElementById('status-icon'); if(ico){ico.textContent=s.icon;ico.style.color=s.color;}
  const dot=document.getElementById('status-dot');  if(dot){dot.style.background=s.dotClr;dot.style.boxShadow=`0 0 10px ${s.dotClr}`;}
  const crd=document.getElementById('status-card'); if(crd) crd.style.borderColor=s.dotClr+'44';
}
setInterval(cycleStatus,4000);

// ── Daily Tips ─────────────────────────────────────
const DAILY_TIPS = [
  'Say "What\'s ahead" anytime to hear nearby obstacles.',
  'Tap the 🎙 button to use voice commands hands-free.',
  'Use Outdoor mode for streets, Indoor for buildings.',
  'Emergency SOS sends your GPS location automatically.',
  'High Contrast mode improves readability in bright light.',
  'Detection log keeps the last 20 obstacle detections.',
  'Speak All on the Assist screen reads every object aloud.',
  'Tap Scan in Detection to manually check left and right.',
];
function rotateTip() {
  const el = document.getElementById('tip-text');
  if (!el) return;
  const tip = DAILY_TIPS[Math.floor(Math.random() * DAILY_TIPS.length)];
  el.style.opacity = '0';
  setTimeout(() => { el.textContent = tip; el.style.opacity = '1'; el.style.transition = 'opacity 0.4s'; }, 300);
}
setInterval(rotateTip, 8000);

// ── Mode Toggle ────────────────────────────────────
function setMode(mode){
  document.getElementById('mode-indoor')?.classList.toggle('active',mode==='indoor');
  document.getElementById('mode-outdoor')?.classList.toggle('active',mode==='outdoor');
  document.getElementById('mode-indoor')?.setAttribute('aria-pressed',mode==='indoor');
  document.getElementById('mode-outdoor')?.setAttribute('aria-pressed',mode==='outdoor');

  // Indoor mode: show badge, disable GPS navigation features
  const navBtnEl   = document.querySelector('.nav-btn[data-screen="navigation"]');
  const badge = document.getElementById('indoor-mode-badge');
  if (mode === 'indoor') {
    if (badge) badge.classList.add('visible');
    if (navBtnEl) navBtnEl.title = 'Navigation disabled in Indoor mode – use Detection instead';
    showToast('🏢 Indoor mode – use Live Detection for guidance');
    speak('Indoor mode activated. Navigation map is disabled. Use the live detection screen for obstacle guidance.');
  } else {
    if (badge) badge.classList.remove('visible');
    if (navBtnEl) navBtnEl.removeAttribute('title');
    showToast('🌍 Outdoor mode – full navigation enabled');
    speak('Outdoor mode activated. Full GPS navigation is now available.');
  }
  saveSetting('navMode', mode);
}

// ── Text-to-Speech ─────────────────────────────────
const speedLevels=['Slow','Normal','Fast','Very Fast'];
let speedIdx=1;
let _voiceEnabled = true;
function speak(text){
  if(!_voiceEnabled) return;
  if(!window.speechSynthesis)return;
  const u=new SpeechSynthesisUtterance(text);
  u.rate={Slow:0.6,Normal:1.0,Fast:1.4,'Very Fast':1.8}[speedLevels[speedIdx]]||1.0;
  u.lang='en-US'; window.speechSynthesis.cancel(); window.speechSynthesis.speak(u);
}

// ── Voice Commands ─────────────────────────────────
let recognition=null, micActive=false, recognizing=false;
const voiceCommands=[
  {patterns:['start navigation','navigate','open map','directions'],
   action:()=>{closeMic();speak('Starting navigation');setTimeout(()=>showScreen('navigation'),600);}},
  {patterns:['open detection','live detection','detect','camera','scan','start scanning'],
   action:()=>{closeMic();speak('Opening live detection');setTimeout(()=>showScreen('detection'),600);}},
  {patterns:['go home','home','main screen','home screen'],
   action:()=>{closeMic();speak('Going home');setTimeout(()=>showScreen('home'),600);}},
  {patterns:['assist','assistance','smart assist','what objects','help me locate'],
   action:()=>{closeMic();speak('Opening smart assistance');setTimeout(()=>showScreen('assistance'),600);}},
  {patterns:['open settings','settings','preferences'],
   action:()=>{closeMic();speak('Opening settings');setTimeout(()=>showScreen('settings'),600);}},
  {patterns:['emergency','sos','help me','call for help','emergency sos'],
   action:()=>{closeMic();speak('Activating emergency SOS');setTimeout(triggerSOS,500);}},
  {patterns:["what's ahead",'what is ahead','any obstacles','obstacles','danger','is it safe'],
   action:()=>{
     let msg = 'I do not see any obstacles in your immediate path.';
     if (latestPredictions && latestPredictions.length > 0) {
       const inPath = latestPredictions.filter(p => isInPathZone(p.bbox, vidW, vidH) && estimateDistance(p.bbox, p.class, vidH) <= 5.0);
       if (inPath.length > 0) {
         const closest = inPath.sort((a, b) => estimateDistance(a.bbox, a.class, vidH) - estimateDistance(b.bbox, b.class, vidH))[0];
         const dist = estimateDistance(closest.bbox, closest.class, vidH);
         msg = `I see a ${closest.class} ${dist < 1 ? 'very close' : dist + ' meters ahead'} in your path.`;
       } else {
         const closestAll = latestPredictions.sort((a, b) => estimateDistance(a.bbox, a.class, vidH) - estimateDistance(b.bbox, b.class, vidH))[0];
         const distAll = estimateDistance(closestAll.bbox, closestAll.class, vidH);
         msg = `The path is clear. There is a ${closestAll.class} nearby at ${distAll} meters.`;
       }
     }
     setMicStatus('Answering…'); speak(msg); showToast('🔊 '+msg.substring(0,40)+'…');
     setTimeout(()=>closeMic(),4500);
   }},
  {patterns:['indoor','indoor mode'],action:()=>{setMode('indoor');closeMic();}},
  {patterns:['outdoor','outdoor mode'],action:()=>{setMode('outdoor');closeMic();}},
  {patterns:['stop navigation','stop nav','cancel navigation','end navigation'],
   action:()=>{closeMic();speak('Stopping navigation');setTimeout(stopNavigation,400);}},
  {patterns:['repeat','repeat that','say again','what did you say'],
   action:()=>{
     const instr = document.getElementById('nav-instruction')?.textContent;
     if (instr && instr !== '—') { speak(instr); showToast('🔊 Repeating instruction'); }
     else speak('No navigation instruction to repeat.');
     setTimeout(()=>closeMic(),2000);
   }},
  {patterns:['speed up','faster','increase speed','speak faster'],
   action:()=>{changeSpeed(1);closeMic();speak('Speaking speed increased');}},
  {patterns:['slow down','slower','decrease speed','speak slower'],
   action:()=>{changeSpeed(-1);closeMic();speak('Speaking speed decreased');}},
  {patterns:['speak all','read all','list objects','what do you see'],
   action:()=>{closeMic();setTimeout(speakAllObjects,400);}},
  {patterns:['torch on','flashlight on','turn on light','light on'],
   action:async ()=>{closeMic();if(!torchOn)await toggleTorch();}},
  {patterns:['torch off','flashlight off','turn off light','light off'],
   action:async ()=>{closeMic();if(torchOn)await toggleTorch();}},
  {patterns:['manual scan','scan left','scan right'],
   action:()=>{closeMic();triggerManualScan();}},
];
function matchCommand(t){t=t.toLowerCase().trim();return voiceCommands.find(c=>c.patterns.some(p=>t.includes(p)))||null;}
function initSR(){
  const SR=window.SpeechRecognition||window.webkitSpeechRecognition; if(!SR)return null;
  const r=new SR(); r.lang='en-US';r.interimResults=true;r.maxAlternatives=3;r.continuous=false;
  r.onstart=()=>{recognizing=true;setMicStatus('Listening…');};
  r.onresult=(ev)=>{
    let interim='',final='';
    for(let i=ev.resultIndex;i<ev.results.length;i++){
      if(ev.results[i].isFinal)final+=ev.results[i][0].transcript;
      else interim+=ev.results[i][0].transcript;
    }
    const el=document.getElementById('mic-transcript'); if(el)el.textContent=final||interim;
    if(final){
      const cmd=matchCommand(final);
      if(cmd){setMicStatus('✓ Recognised');cmd.action();}
      else{setMicStatus('Not recognised – try again');showToast(`🎙 Heard: "${final.trim()}"`);setTimeout(()=>{if(micActive)startListening();},1500);}
    }
  };
  r.onerror=(e)=>{recognizing=false;if(e.error==='no-speech'&&micActive)startListening();
    else if(e.error==='not-allowed'){setMicStatus('Mic access denied');setTimeout(closeMic,2000);}
    else if(micActive)setTimeout(startListening,1200);};
  r.onend=()=>{recognizing=false;if(micActive)startListening();};
  return r;
}
function startListening(){if(!recognition)recognition=initSR();if(!recognition){setMicStatus('Use Chrome/Edge for voice');return;}if(!recognizing){try{recognition.start();}catch(e){}}}
function setMicStatus(t){const el=document.getElementById('mic-status-text');if(el)el.textContent=t;}
function toggleMic(){
  if(micActive){closeMic();return;}
  micActive=true;
  const ov=document.getElementById('mic-overlay');
  ov.removeAttribute('hidden');ov.style.display='flex';
  const tr=document.getElementById('mic-transcript');if(tr)tr.textContent='';
  // Show waveform on home screen
  const hw=document.getElementById('home-wave');if(hw)hw.style.display='flex';
  startListening();
}
function closeMic(){
  micActive=false;
  if(recognition&&recognizing){try{recognition.stop();}catch(e){}}
  recognizing=false;
  const ov=document.getElementById('mic-overlay');ov.setAttribute('hidden','');ov.style.display='none';
  // Hide waveform
  const hw=document.getElementById('home-wave');if(hw)hw.style.display='none';
}

// ── Detection Controls ─────────────────────────────
function toggleDetAudio(btn){
  btn.classList.toggle('active-ctrl');
  _voiceEnabled = btn.classList.contains('active-ctrl');
  showToast(btn.classList.contains('active-ctrl')?'🔊 Audio ON':'🔇 Audio OFF');
  saveSetting('audioEnabled', _voiceEnabled);
}

// ── Settings ───────────────────────────────────────
function changeSpeed(delta){
  speedIdx=Math.max(0,Math.min(speedLevels.length-1,speedIdx+delta));
  const el=document.getElementById('spd-display');if(el)el.textContent=speedLevels[speedIdx];
  showToast('🔊 Speed: '+speedLevels[speedIdx]);
  saveSetting('speedIdx', speedIdx);
}
const sensLabels=['Low – fewer alerts','Medium – balanced alerts','High – maximum alerts'];
function changeSensitivity(val){
  const el=document.getElementById('sensitivity-desc');if(el)el.textContent=sensLabels[val-1];
  showToast('⚙ Sensitivity: '+sensLabels[val-1].split('–')[0].trim());
  // Adjust alert distance based on sensitivity
  // 1=Low: 1.5m, 2=Medium: 2.0m, 3=High: 3.0m
  const distMap = [1.5, 2.0, 3.0];
  // We can't reassign const, so we store for use
  saveSetting('sensitivity', parseInt(val));
}
const langNames={en:'English',es:'Español',fr:'Français',hi:'हिन्दी',ta:'தமிழ்'};
function changeLang(val){
  showToast('🌐 Language: '+(langNames[val]||val));
  if(recognition)recognition.lang=({en:'en-US',es:'es-ES',fr:'fr-FR',hi:'hi-IN',ta:'ta-IN'}[val]||'en-US');
  saveSetting('language', val);
}

function handleToggle(cb, s) {
  const labels = {
    voice:'Voice Guidance', alerts:'Alert Sounds', haptic:'Haptic Feedback',
    highContrast:'High Contrast Mode', largeText:'Large Text Mode', nightDim:'Night Dim Mode',
  };
  showToast((cb.checked?'✓ ':'✕ ')+(labels[s]||s)+(cb.checked?' enabled':' disabled'));
  saveSetting(s, cb.checked);

  // Apply accessibility modes
  if (s === 'highContrast') applyHighContrast(cb.checked);
  if (s === 'largeText')    applyLargeText(cb.checked);
  if (s === 'nightDim')     applyNightDim(cb.checked);
  if (s === 'voice')        _voiceEnabled = cb.checked;
}

function applyHighContrast(on) {
  document.body.classList.toggle('hc-mode', on);
}
function applyLargeText(on) {
  document.body.classList.toggle('large-text', on);
}
function applyNightDim(on) {
  const overlay = document.getElementById('night-dim-overlay');
  if (overlay) overlay.style.display = on ? 'block' : 'none';
}

// ── Emergency Contact Modal ────────────────────────
function openContactModal() {
  const modal = document.getElementById('contact-modal');
  if (!modal) return;
  // Pre-fill with saved contact
  const saved      = loadSetting('emergencyContact', '');
  const savedPhone = loadSetting('emergencyContactPhone', '');
  if (saved && saved !== 'Not set') {
    // Format: "Name (Relation) · Phone" or "Name · Phone"
    const phoneIdx  = saved.lastIndexOf(' · ');
    const namePart  = phoneIdx >= 0 ? saved.slice(0, phoneIdx) : saved;
    const phonePart = phoneIdx >= 0 ? saved.slice(phoneIdx + 3) : savedPhone;
    // Extract relation from name part if present
    const relMatch  = namePart.match(/^(.+?)\s*\((.+?)\)\s*$/);
    const nameEl    = document.getElementById('contact-name-input');
    const phoneEl   = document.getElementById('contact-phone-input');
    const relEl     = document.getElementById('contact-relation-input');
    if (nameEl)  nameEl.value  = relMatch ? relMatch[1].trim() : namePart;
    if (phoneEl) phoneEl.value = phonePart;
    if (relEl)   relEl.value   = relMatch ? relMatch[2].trim() : '';
  }
  modal.removeAttribute('hidden');
  modal.style.display = 'flex';
  setTimeout(() => document.getElementById('contact-name-input')?.focus(), 100);
}

function closeContactModal() {
  const modal = document.getElementById('contact-modal');
  if (!modal) return;
  modal.setAttribute('hidden', '');
  modal.style.display = 'none';
}

function saveContact() {
  const name     = document.getElementById('contact-name-input')?.value?.trim();
  const phone    = document.getElementById('contact-phone-input')?.value?.trim();
  const relation = document.getElementById('contact-relation-input')?.value?.trim();
  if (!name) { showToast('⚠ Please enter the contact name'); return; }
  if (!phone) { showToast('⚠ Please enter a phone number for SMS alerts'); return; }
  const contactStr = name + (relation ? ` (${relation})` : '') + ' · ' + phone;
  const el = document.getElementById('emergency-contact-name');
  if (el) el.textContent = contactStr;
  saveSetting('emergencyContact', contactStr);
  saveSetting('emergencyContactPhone', phone);
  showToast('✓ Emergency contact saved');
  speak('Emergency contact saved. They will be notified via SMS in an SOS emergency.');
  closeContactModal();
}

// ── Settings Persistence ────────────────────────────
function saveSetting(key, value) {
  try { localStorage.setItem('accesslens_'+key, JSON.stringify(value)); } catch(e) {}
}
function loadSetting(key, defaultVal) {
  try {
    const v = localStorage.getItem('accesslens_'+key);
    return v !== null ? JSON.parse(v) : defaultVal;
  } catch(e) { return defaultVal; }
}

function initSettings() {
  // Voice
  _voiceEnabled = loadSetting('voice', true);
  const cbVoice = document.getElementById('toggle-voice');
  if(cbVoice) cbVoice.checked = _voiceEnabled;

  // Alerts
  const vAlerts = loadSetting('alerts', true);
  const cbAlerts = document.getElementById('toggle-alerts');
  if(cbAlerts) cbAlerts.checked = vAlerts;

  // Haptic
  const cbHaptic = document.getElementById('toggle-haptic');
  if(cbHaptic) cbHaptic.checked = loadSetting('haptic', true);

  // Speed
  speedIdx = loadSetting('speedIdx', 1);
  const elSpd = document.getElementById('spd-display');
  if (elSpd) elSpd.textContent = speedLevels[speedIdx];

  // Sensitivity
  const sens = loadSetting('sensitivity', 2);
  const sensSlider = document.querySelector('.sens-slider');
  if (sensSlider) {
    sensSlider.value = sens;
    const sDesc = document.getElementById('sensitivity-desc');
    if (sDesc) sDesc.textContent = sensLabels[sens-1];
  }

  // Language
  const lang = loadSetting('language', 'en');
  const langSel = document.querySelector('.lang-select');
  if(langSel) langSel.value = lang;

  // Emergency Contact
  const contact = loadSetting('emergencyContact', 'Not set');
  const eContactEl = document.getElementById('emergency-contact-name');
  if(eContactEl) eContactEl.textContent = contact;

  // High Contrast
  const hc = loadSetting('highContrast', false);
  const cbHC = document.getElementById('toggle-hc');
  if (cbHC) cbHC.checked = hc;
  if (hc) applyHighContrast(true);

  // Large Text
  const lt = loadSetting('largeText', false);
  const cbLT = document.getElementById('toggle-lt');
  if (cbLT) cbLT.checked = lt;
  if (lt) applyLargeText(true);

  // Night Dim
  const nd = loadSetting('nightDim', false);
  const cbND = document.getElementById('toggle-nd');
  if (cbND) cbND.checked = nd;
  if (nd) applyNightDim(true);

  // Navigation Mode
  const navMode = loadSetting('navMode', 'indoor');
  setMode(navMode);

  // GPS check
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(
      () => setHeaderBadge('hdr-gps', '📍', 'active'),
      () => setHeaderBadge('hdr-gps', '📍', 'error')
    );
  }
}

// ── Reset All Settings ────────────────────────────
function resetAllSettings() {
  if (!confirm('Reset all settings to defaults? This cannot be undone.')) return;
  const keys = ['voice','alerts','haptic','speedIdx','sensitivity','language','emergencyContact','emergencyContactPhone',
                 'highContrast','largeText','nightDim','navMode','audioEnabled'];
  keys.forEach(k => localStorage.removeItem('accesslens_' + k));
  showToast('✓ Settings reset to defaults');
  speak('Settings have been reset to defaults.');
  // Re-init
  initSettings();
}

// ── Optional backend helpers (works on static hosts like GitHub Pages) ──
// Returns parsed JSON on success, or null when no real API server answers
// (a static host replies 404/HTML, which must NOT be treated as success).
// null = no backend (GitHub Pages). Set window.ACCESSLENS_API_BASE before app.js
// to point at a separately hosted Node server (e.g. 'https://my-app.onrender.com').
const API_BASE = (typeof window.ACCESSLENS_API_BASE === 'string')
  ? window.ACCESSLENS_API_BASE.replace(/\/$/, '')
  : (location.hostname.endsWith('github.io') ? null : '');

async function apiPost(url, body) {
  if (API_BASE === null) return null;
  try {
    const resp = await fetch(API_BASE + url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    if (!resp.ok) return null;
    const type = resp.headers.get('content-type') || '';
    if (!type.includes('application/json')) return null;
    return await resp.json();
  } catch (e) { return null; }
}

function pushLocal(key, entry, cap = 200) {
  try {
    const arr = JSON.parse(localStorage.getItem('accesslens_' + key) || '[]');
    arr.unshift(entry);
    localStorage.setItem('accesslens_' + key, JSON.stringify(arr.slice(0, cap)));
  } catch (e) { /* storage full or blocked – ignore */ }
}

const EMERGENCY_NUMBER = '112'; // India's unified emergency number – change for other countries

function cleanPhone(p) { return String(p || '').replace(/[^\d+]/g, ''); }

// Browsers cannot send SMS silently, so we show big tap targets that open the
// phone's own SMS / dialer with the message and map link pre-filled.
function showSOSActions(contactPhone, message) {
  document.getElementById('sos-actions')?.remove();
  const phone = cleanPhone(contactPhone);
  const box = document.createElement('div');
  box.id = 'sos-actions';
  box.setAttribute('role', 'alertdialog');
  box.setAttribute('aria-label', 'Emergency actions');
  box.style.cssText = 'position:fixed;left:12px;right:12px;bottom:90px;z-index:10000;display:flex;' +
    'flex-direction:column;gap:10px;padding:14px;border-radius:16px;background:#1a0b10;' +
    'border:2px solid #ff3b5c;box-shadow:0 8px 32px rgba(0,0,0,.6)';
  const mk = (href, text) => {
    const a = document.createElement('a');
    a.href = href; a.textContent = text;
    a.style.cssText = 'display:block;text-align:center;padding:16px;border-radius:12px;font-weight:800;' +
      'font-size:1.1rem;color:#fff;background:#ff3b5c;text-decoration:none';
    return a;
  };
  if (phone) {
    box.appendChild(mk('sms:' + phone + '?body=' + encodeURIComponent(message), '📩 Send SOS SMS to your contact'));
    box.appendChild(mk('tel:' + phone, '📞 Call your contact'));
  }
  box.appendChild(mk('tel:' + EMERGENCY_NUMBER, '🚑 Call emergency services (' + EMERGENCY_NUMBER + ')'));
  const close = document.createElement('button');
  close.textContent = 'Dismiss';
  close.style.cssText = 'padding:12px;border-radius:12px;border:1px solid #556;background:transparent;color:#fff;font-size:1rem';
  close.onclick = () => box.remove();
  box.appendChild(close);
  document.body.appendChild(box);
  box.querySelector('a')?.focus();
}

// ── SOS with GPS Location ─────────────────────────
let sosTimer=null, sosCount=5, sosRunning=false;
let sosLocation = null;

function triggerSOS(){
  if(sosRunning)return;
  sosRunning=true;sosCount=5;
  const ov=document.getElementById('sos-overlay'),cd=document.getElementById('sos-countdown');
  ov.removeAttribute('hidden');ov.style.display='flex';
  if(cd)cd.textContent=sosCount;

  // Try to get GPS location
  const locDisplay = document.getElementById('sos-location-display');
  const locText    = document.getElementById('sos-loc-text');
  if (locDisplay) locDisplay.style.display = 'flex';
  if (locText)    locText.textContent = 'Acquiring location…';

  navigator.geolocation?.getCurrentPosition(
    pos => {
      sosLocation = { lat: pos.coords.latitude, lng: pos.coords.longitude };
      if (locText) locText.textContent = `${sosLocation.lat.toFixed(4)}, ${sosLocation.lng.toFixed(4)}`;
    },
    () => { sosLocation = null; if (locText) locText.textContent = 'Location unavailable'; }
  );

  speak('Emergency SOS activated. Counting down from 5.');
  vibrate([500, 200, 500, 200, 500]);

  sosTimer=setInterval(async ()=>{
    sosCount--;
    if(cd)cd.textContent=sosCount;
    vibrate([200]);
    playBeep('sos');
    if(sosCount<=0){
      clearInterval(sosTimer);sosRunning=false;
      ov.setAttribute('hidden','');ov.style.display='none';
      const contactStr  = document.getElementById('emergency-contact-name')?.textContent || '';
      const contactPhone = loadSetting('emergencyContactPhone', '');
      const mapsLink = sosLocation
        ? `https://www.google.com/maps?q=${sosLocation.lat},${sosLocation.lng}` : '';
      const smsText = 'EMERGENCY SOS from AccessLens. I need help.' +
        (mapsLink ? ' My location: ' + mapsLink : ' (GPS location unavailable)');
      const evt = { timestamp: new Date().toISOString(), contact: contactStr,
                    phone: contactPhone, location: sosLocation, mapsLink };
      pushLocal('sos_history', evt, 50);

      const data = await apiPost('/api/sos', {
        contact: contactStr,
        contactPhone,
        message: 'Emergency SOS activated from AccessLens.',
        location: sosLocation,
        timestamp: evt.timestamp,
      });

      if (data && data.sms && data.sms.success && data.sms.method === 'twilio') {
        showToast('🆘 SOS sent + SMS dispatched!');
        speak('Emergency SOS sent. Your contact has been notified by SMS. Help is on the way.');
      } else {
        // No SMS server available: hand over to the phone's own SMS / dialer.
        showSOSActions(contactPhone, smsText);
        if (contactPhone) {
          showToast('🆘 Tap "Send SOS SMS" to alert your contact');
          speak('S O S ready. Tap the large button to send an S M S to your contact, or call emergency services.');
        } else {
          showToast('🆘 No contact set – call emergency services');
          speak('No emergency contact is set. Use the large button to call emergency services.');
        }
      }
      if (locDisplay) locDisplay.style.display = 'none';
    }
  },1000);
}

function cancelSOS(){
  clearInterval(sosTimer);sosRunning=false;
  const ov=document.getElementById('sos-overlay');ov.setAttribute('hidden','');ov.style.display='none';
  const locDisplay = document.getElementById('sos-location-display');
  if (locDisplay) locDisplay.style.display = 'none';
  sosLocation = null;
  showToast('✕ SOS cancelled');speak('SOS cancelled');
}

// ── Toast ──────────────────────────────────────────
let toastTimer=null;
function showToast(msg){
  const t=document.getElementById('toast');if(!t)return;
  if(toastTimer)clearTimeout(toastTimer);
  t.textContent=msg;t.style.display='block';t.setAttribute('aria-hidden','false');
  requestAnimationFrame(()=>t.classList.add('show'));
  toastTimer=setTimeout(()=>{t.classList.remove('show');setTimeout(()=>{t.style.display='none';t.setAttribute('aria-hidden','true');},350);},2800);
}

// ── Warning Banner Cycling (non-detection screens) ─
const warnings=[
  {text:'⚠ Stairs Ahead – Stop!',safe:false},
  {text:'⚠ Person Approaching',safe:false},
  {text:'⚠ Vehicle Nearby',safe:false},
  {text:'✓ Path Clear – Proceed',safe:true}
];
let warnIdx=0;
function cycleWarning(){
  if(document.getElementById('screen-detection')?.classList.contains('active'))return;
  warnIdx=(warnIdx+1)%warnings.length;
  const b=document.getElementById('warn-banner'),tx=b?.querySelector('.warn-text');
  if(tx){
    b.style.opacity='0';
    setTimeout(()=>{
      tx.textContent=warnings[warnIdx].text;
      b.style.background=warnings[warnIdx].safe
        ?'linear-gradient(135deg,rgba(0,180,80,.95),rgba(0,140,60,.9))'
        :'linear-gradient(135deg,rgba(255,60,60,.95),rgba(200,20,20,.9))';
      b.style.opacity='1';b.style.transition='opacity 0.4s';
    },300);
  }
}
setInterval(cycleWarning,3500);

// ── GPS Heading (Compass) ─────────────────────────
let heading = null;
function startCompass() {
  if ('ondeviceorientationabsolute' in window) {
    window.addEventListener('deviceorientationabsolute', onOrientation, true);
  } else if ('ondeviceorientation' in window) {
    window.addEventListener('deviceorientation', onOrientation, true);
  }
}
function onOrientation(e) {
  if (e.alpha !== null) {
    heading = Math.round(e.alpha);
    const btn = document.getElementById('compass-btn');
    if (btn && btn.style.display !== 'none') {
      const dirs = ['N','NE','E','SE','S','SW','W','NW'];
      const dir  = dirs[Math.round(heading / 45) % 8];
      btn.title = `Heading: ${heading}° ${dir}`;
    }
  }
}

// ── Init ───────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  initSettings();
  // Handle manifest shortcuts: ?screen=detection | ?screen=navigation | ?sos=1
  try {
    const q = new URLSearchParams(location.search);
    const scr = q.get('screen');
    if (scr && document.querySelector('.nav-btn[data-screen="' + CSS.escape(scr) + '"]')) showScreen(scr);
    if (q.get('sos') === '1') setTimeout(triggerSOS, 400);
  } catch (e) { /* ignore malformed query */ }
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('sw.js').catch(e => console.warn('PWA SW error:', e));
  }
  document.getElementById('arr-left')?.classList.add('active-arr');
  const ph=document.getElementById('camera-off-placeholder'), v=document.getElementById('camera-video');
  if(ph)ph.style.display='flex';if(v)v.style.display='none';
  if(!window.SpeechRecognition&&!window.webkitSpeechRecognition){
    const h=document.querySelector('.mic-hint');if(h)h.innerHTML='⚠ Use Chrome or Edge for voice commands.'
  }
  startCompass();
  // Set AI badge to inactive initially
  setHeaderBadge('hdr-ai',  '🤖', 'inactive');
  setHeaderBadge('hdr-cam', '📷', 'inactive');
  setHeaderBadge('hdr-gps', '📍', 'inactive');
  // Rotate first tip
  rotateTip();
  // Battery + Connectivity monitoring
  initSystemMonitor();
  // Onboarding (first run)
  checkOnboarding();
});
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') { closeMic(); cancelSOS(); closeContactModal(); closeDestModal(); }
});

/* =====================================================================
   NAVMANAGER – Real-Time Navigation
   Nominatim geocoding · OSRM pedestrian routing · Leaflet map
   Anti-backtrack: only advance steps that reduce distance to destination
   ===================================================================== */

const Nav = (() => {
  let map          = null;
  let userMarker   = null;
  let destMarker   = null;
  let routeLayer   = null;
  let pathTrail    = null;   // tracks where user walked
  let pathCoords   = [];     // accumulated GPS trail
  let gpsWatch     = null;
  let steps        = [];
  let stepIdx      = 0;
  let destLatLng   = null;
  let destName     = '';
  let totalDistM   = 0;
  let lastInstruction = '';
  let suggTimer    = null;
  let navigationActive = false;

  function haversine(lat1, lon1, lat2, lon2) {
    const R = 6371000;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat/2)**2 +
              Math.cos(lat1*Math.PI/180) * Math.cos(lat2*Math.PI/180) * Math.sin(dLon/2)**2;
    return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  }

  function fmtDist(m) {
    return m >= 1000 ? `${(m/1000).toFixed(1)} km` : `${Math.round(m)} m`;
  }
  function fmtTime(s) {
    const m = Math.round(s / 60);
    return m < 1 ? '<1 min' : `${m} min`;
  }

  function turnIcon(maneuver) {
    if (!maneuver) return '🔊';
    const t = (maneuver.modifier || '') + '|' + (maneuver.type || '');
    if (/left/.test(t))         return '↰';
    if (/right/.test(t))        return '↱';
    if (/u.turn/i.test(t))      return '↩';
    if (/arrive/i.test(t))      return '🏁';
    if (/depart/i.test(t))      return '🚶';
    return '↑';
  }

  function stepText(step) {
    const m = step.maneuver;
    const type = m?.type || '';
    const mod  = m?.modifier || '';
    const name = step.name || '';
    const dist = fmtDist(step.distance);

    if (type === 'arrive')  return `You have arrived at ${destName}`;
    if (type === 'depart')  return `Head ${mod || 'forward'}${name ? ' on ' + name : ''}`;
    if (type === 'turn')    return `Turn ${mod}${name ? ' onto ' + name : ''} in ${dist}`;
    if (type === 'continue')return `Continue straight${name ? ' on ' + name : ''} for ${dist}`;
    if (type === 'roundabout') return `At the roundabout, take exit ${m.exit || ''}`;
    return `${capitalise(type)} ${mod}${name ? ' on ' + name : ''} in ${dist}`;
  }

  function setInstruction(step) {
    const text = stepText(step);
    const icon = turnIcon(step.maneuver);
    const dist = fmtDist(step.distance);

    document.getElementById('nav-instruction').textContent  = text;
    document.getElementById('nav-instr-sub').textContent    = `In ${dist}`;
    document.getElementById('nav-turn-icon').textContent    = icon;

    if (text !== lastInstruction) {
      lastInstruction = text;
      speak(text);
    }

    document.getElementById('nav-instr-card').style.display  = 'flex';
    document.getElementById('nav-steps-panel').style.display = 'block';
    document.getElementById('eta-bar').style.display         = 'flex';
    document.getElementById('reroute-btn').style.display     = 'inline-flex';
    document.getElementById('stop-nav-btn').style.display    = 'block';
    document.getElementById('compass-btn').style.display     = 'inline-flex';
  }

  function renderStepsList() {
    const ul = document.getElementById('nav-steps-list');
    if (!ul) return;
    ul.innerHTML = '';
    steps.slice(stepIdx, stepIdx + 5).forEach((s, i) => {
      const li = document.createElement('li');
      li.className = 'step-item' + (i === 0 ? ' step-current' : '');
      li.setAttribute('role', 'listitem');
      const risk = s.maneuver?.type === 'arrive' ? 'safe' : i === 0 ? 'medium' : 'safe';
      li.innerHTML = `
        <span class="step-num">${stepIdx + i + 1}</span>
        <span class="step-desc">${stepText(s)}</span>
        <span class="step-risk ${risk}">${i===0?'Now':fmtDist(s.distance)}</span>
      `;
      ul.appendChild(li);
    });
  }

  function updateETA(userLat, userLon) {
    if (!destLatLng) return;
    const distLeft = haversine(userLat, userLon, destLatLng.lat, destLatLng.lng);
    const timeLeft = distLeft / 1.2;
    document.getElementById('eta-dist').textContent  = fmtDist(distLeft);
    document.getElementById('eta-time').textContent  = fmtTime(timeLeft);
    document.getElementById('eta-route').textContent = 'Walk';
    document.getElementById('nav-status-txt').textContent = `To: ${destName}`;
  }

  function advanceStep(userLat, userLon) {
    if (stepIdx >= steps.length - 1) return;
    const step = steps[stepIdx];
    if (!step.geometry?.coordinates?.length) return;

    const coords = step.geometry.coordinates;
    const endCoord = coords[coords.length - 1];
    const endLat = endCoord[1], endLon = endCoord[0];

    const distToStepEnd = haversine(userLat, userLon, endLat, endLon);
    const ARRIVAL_RADIUS = Math.max(15, step.distance * 0.2);

    if (distToStepEnd > ARRIVAL_RADIUS) return;

    const nextStep = steps[stepIdx + 1];
    if (nextStep?.geometry?.coordinates?.length) {
      const nextCoords = nextStep.geometry.coordinates;
      const nextEnd = nextCoords[nextCoords.length - 1];
      const distNextToDest = haversine(nextEnd[1], nextEnd[0], destLatLng.lat, destLatLng.lng);
      const distCurrToDest = haversine(endLat, endLon, destLatLng.lat, destLatLng.lng);
      if (distNextToDest > distCurrToDest + 20) {
        rerouteNav();
        return;
      }
    }

    stepIdx++;
    setInstruction(steps[stepIdx]);
    renderStepsList();
  }

  function initMap(lat, lon) {
    if (map) return;
    map = L.map('leaflet-map', {
      center: [lat, lon],
      zoom: 18,
      zoomControl: true,
      attributionControl: false,
    });
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 20,
    }).addTo(map);

    const icon = L.divIcon({
      className: '',
      html: `<div style="
        width:20px;height:20px;border-radius:50%;
        background:#3399ff;border:3px solid #fff;
        box-shadow:0 0 12px rgba(0,150,255,0.8);
        position:relative;
      "><div style="
        position:absolute;top:-6px;left:-6px;right:-6px;bottom:-6px;
        border-radius:50%;border:2px solid rgba(0,150,255,0.4);
        animation:expandRing 2s ease-out infinite;
      "></div></div>`,
      iconSize: [20, 20],
      iconAnchor: [10, 10],
    });
    userMarker = L.marker([lat, lon], { icon, zIndexOffset: 1000 }).addTo(map);
  }

  function drawRoute(geojsonCoords) {
    if (routeLayer) map.removeLayer(routeLayer);
    const latlngs = geojsonCoords.map(c => [c[1], c[0]]);
    // Glow layer
    L.polyline(latlngs, {
      color: '#00d4ff', weight: 12, opacity: 0.15,
    }).addTo(map);
    routeLayer = L.polyline(latlngs, {
      color: '#00d4ff', weight: 5, opacity: 0.9,
      dashArray: '10, 6', lineCap: 'round',
    }).addTo(map);
    map.fitBounds(routeLayer.getBounds(), { padding: [60, 60] });
  }

  // Draw footprint trail
  function updateTrail(lat, lon) {
    pathCoords.push([lat, lon]);
    if (pathTrail) map.removeLayer(pathTrail);
    if (pathCoords.length > 1) {
      pathTrail = L.polyline(pathCoords, {
        color: '#00ff88', weight: 3, opacity: 0.6,
        dashArray: '4, 4',
      }).addTo(map);
    }
  }

  async function fetchRoute(fromLat, fromLon, toLat, toLon) {
    const url = `https://router.project-osrm.org/route/v1/foot/` +
      `${fromLon},${fromLat};${toLon},${toLat}` +
      `?overview=full&geometries=geojson&steps=true&annotations=false`;
    setNavStatus('🗺 Calculating route…');
    try {
      const res  = await fetch(url);
      const data = await res.json();
      if (!data.routes?.length) throw new Error('No route found');
      const route = data.routes[0];
      totalDistM  = route.distance;
      const allSteps = route.legs.flatMap(l => l.steps);
      return { steps: allSteps, coords: route.geometry.coordinates };
    } catch(e) {
      showToast('⚠ Route not found. Check destination and try again.');
      setNavStatus('⚠ Route failed');
      return null;
    }
  }

  function startGPS() {
    if (!navigator.geolocation) {
      showToast('⚠ Geolocation not supported');
      return;
    }
    gpsWatch = navigator.geolocation.watchPosition(
      pos => onPosition(pos.coords.latitude, pos.coords.longitude, pos.coords.accuracy),
      err => {
        console.warn('GPS err:', err);
        if (err.code === 1) showToast('⚠ Location permission denied');
      },
      { enableHighAccuracy: true, maximumAge: 2000, timeout: 10000 }
    );
  }

  function stopGPS() {
    if (gpsWatch != null) { navigator.geolocation.clearWatch(gpsWatch); gpsWatch = null; }
  }

  function onPosition(lat, lon, acc) {
    if (userMarker) userMarker.setLatLng([lat, lon]);
    if (map) map.panTo([lat, lon], { animate: true, duration: 0.5 });
    setHeaderBadge('hdr-gps', '📍', 'active');
    updateETA(lat, lon);
    advanceStep(lat, lon);
    updateTrail(lat, lon);

    if (destLatLng) {
      const distToDest = haversine(lat, lon, destLatLng.lat, destLatLng.lng);
      if (distToDest < 20) {
        onArrived();
        return;
      }
    }
  }

  function onArrived() {
    stopGPS();
    navigationActive = false;
    speak(`You have arrived at ${destName}`);
    showToast(`🏁 Arrived at ${destName}!`);
    setNavStatus('🏁 Arrived!');
    document.getElementById('nav-instruction').textContent = `You have arrived at ${destName}`;
    document.getElementById('nav-turn-icon').textContent   = '🏁';
    document.getElementById('eta-dist').textContent        = '0 m';
    document.getElementById('eta-time').textContent        = '—';
    document.getElementById('eta-route').textContent       = 'Done';
    document.getElementById('stop-nav-btn').style.display  = 'none';
    vibrate([500, 200, 500, 200, 500, 200, 500]);
  }

  function setNavStatus(txt) {
    const el = document.getElementById('nav-status-txt');
    if (el) el.textContent = txt;
  }

  function openDestModal() {
    const modal = document.getElementById('dest-modal');
    modal.removeAttribute('hidden');
    modal.style.display = 'flex';
    const input = document.getElementById('dest-input');
    input.value = '';
    document.getElementById('dest-suggestions').innerHTML = '';
    setTimeout(() => input.focus(), 100);
  }

  function closeDestModal() {
    const modal = document.getElementById('dest-modal');
    modal.setAttribute('hidden', '');
    modal.style.display = 'none';
  }

  async function geocode(query) {
    if (query.length < 3) return [];
    const url = `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&limit=4&addressdetails=1`;
    const res  = await fetch(url, { headers: { Accept: 'application/json' } });
    return await res.json();
  }

  function setupSuggestions() {
    const input = document.getElementById('dest-input');
    if (!input) return;
    input.addEventListener('input', () => {
      clearTimeout(suggTimer);
      suggTimer = setTimeout(async () => {
        const results = await geocode(input.value);
        const box = document.getElementById('dest-suggestions');
        box.innerHTML = '';
        results.forEach(r => {
          const btn = document.createElement('button');
          btn.className = 'dest-suggestion';
          const name = r.namedetails?.name || r.display_name.split(',')[0];
          const addr = r.display_name;
          btn.innerHTML = `<strong>${name}</strong><small>${addr}</small>`;
          btn.onclick = () => {
            input.value = name;
            box.innerHTML = '';
            destLatLng = { lat: parseFloat(r.lat), lng: parseFloat(r.lon) };
            destName   = name;
          };
          box.appendChild(btn);
        });
      }, 350);
    });
    input.addEventListener('keydown', e => { if (e.key === 'Enter') startNavFromModal(); });
  }

  async function startNavFromModal() {
    const input = document.getElementById('dest-input');
    const query = input?.value?.trim();
    if (!query) { showToast('⚠ Please enter a destination'); return; }
    const btn = document.getElementById('dest-go-btn');
    if (btn) { btn.disabled = true; btn.textContent = 'Searching…'; }

    if (!destLatLng) {
      const results = await geocode(query);
      if (!results.length) {
        showToast('⚠ Destination not found');
        if (btn) { btn.disabled = false; btn.innerHTML = '<span>▶</span> Start Navigation'; }
        return;
      }
      const r  = results[0];
      destLatLng = { lat: parseFloat(r.lat), lng: parseFloat(r.lon) };
      destName   = r.namedetails?.name || r.display_name.split(',')[0];
    }

    closeDestModal();
    if (btn) { btn.disabled = false; btn.innerHTML = '<span>▶</span> Start Navigation'; }
    beginNavigation();
  }

  async function beginNavigation() {
    setNavStatus('📍 Getting location…');
    navigationActive = true;
    pathCoords = [];

    navigator.geolocation.getCurrentPosition(async pos => {
      const fromLat = pos.coords.latitude;
      const fromLon = pos.coords.longitude;

      initMap(fromLat, fromLon);

      if (destMarker) map.removeLayer(destMarker);
      const destIcon = L.divIcon({
        className: '',
        html: `<div style="
          width:28px;height:28px;border-radius:50% 50% 50% 0;
          background: linear-gradient(135deg,#00ff88,#00aaff);
          transform:rotate(-45deg);
          border:2px solid white;
          box-shadow:0 0 14px rgba(0,255,136,0.7);
        "></div>`,
        iconSize: [28, 28], iconAnchor: [14, 28],
      });
      destMarker = L.marker([destLatLng.lat, destLatLng.lng], { icon: destIcon })
        .addTo(map)
        .bindPopup(`<b>🏁 ${destName}</b>`);

      const route = await fetchRoute(fromLat, fromLon, destLatLng.lat, destLatLng.lng);
      if (!route) { navigationActive = false; return; }

      steps   = route.steps;
      stepIdx = 0;
      drawRoute(route.coords);
      setInstruction(steps[0]);
      renderStepsList();
      startGPS();

      speak(`Route to ${destName} found. ${fmtDist(totalDistM)} ahead. ${stepText(steps[0])}`);
      showToast(`🗺 Navigating to ${destName}`);
      setNavStatus(`Navigating • ${fmtDist(totalDistM)}`);

    }, () => {
      showToast('⚠ Location permission denied');
      setNavStatus('⚠ Location unavailable');
      navigationActive = false;
    }, { enableHighAccuracy: true, timeout: 12000 });
  }

  function rerouteNav() {
    if (!destLatLng) return;
    stopGPS();
    speak('Recalculating route');
    showToast('↺ Recalculating…');
    pathCoords = [];
    navigator.geolocation.getCurrentPosition(async pos => {
      const fromLat = pos.coords.latitude;
      const fromLon = pos.coords.longitude;
      const route = await fetchRoute(fromLat, fromLon, destLatLng.lat, destLatLng.lng);
      if (!route) return;
      steps   = route.steps;
      stepIdx = 0;
      drawRoute(route.coords);
      setInstruction(steps[0]);
      renderStepsList();
      startGPS();
      speak(`Rerouted. ${stepText(steps[0])}`);
    }, null, { enableHighAccuracy: true });
  }

  function stopNav() {
    stopGPS();
    steps      = [];
    stepIdx    = 0;
    destLatLng = null;
    destName   = '';
    navigationActive = false;
    pathCoords = [];
    if (pathTrail && map) { map.removeLayer(pathTrail); pathTrail = null; }
    if (routeLayer && map) { map.removeLayer(routeLayer); routeLayer = null; }
    if (destMarker && map) { map.removeLayer(destMarker); destMarker = null; }
    document.getElementById('nav-instr-card').style.display  = 'none';
    document.getElementById('nav-steps-panel').style.display = 'none';
    document.getElementById('eta-bar').style.display         = 'none';
    document.getElementById('reroute-btn').style.display     = 'none';
    document.getElementById('stop-nav-btn').style.display    = 'none';
    document.getElementById('compass-btn').style.display     = 'none';
    setNavStatus('Enter destination');
    showToast('⬛ Navigation stopped');
    speak('Navigation stopped.');
  }

  function onNavScreenEnter() {
    if (!destLatLng) {
      openDestModal();
      navigator.geolocation.getCurrentPosition(pos => {
        initMap(pos.coords.latitude, pos.coords.longitude);
      }, () => {
        initMap(13.0827, 80.2707); // fallback: Chennai
      }, { timeout: 5000 });
    }
    if (map) setTimeout(() => map.invalidateSize(), 200);
  }

  return { openDestModal, closeDestModal, startNavFromModal, rerouteNav, stopNav, onNavScreenEnter, setupSuggestions };
})();

// ── Stop Navigation (exposed globally) ────────────
function stopNavigation() {
  Nav.stopNav();
}

// ── Nav screen hook ───────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.nav-btn[data-screen="navigation"]').forEach(btn => {
    btn.addEventListener('click', () => { Nav.onNavScreenEnter(); }, true);
  });
}, { once: true });

// ── Global functions called from HTML ─────────────
function startNavFromModal()    { Nav.startNavFromModal(); }
function closeDestModal()       { Nav.closeDestModal(); }
function rerouteNav()           { Nav.rerouteNav(); }
function navRepeatInstruction() { speak(document.getElementById('nav-instruction')?.textContent||''); }

// ── Init suggestions on DOM ready ─────────────────
document.addEventListener('DOMContentLoaded', () => {
  Nav.setupSuggestions();
});

/* =====================================================================
   BATTERY + CONNECTIVITY MONITORING
   ===================================================================== */
function initSystemMonitor() {
  // ── Offline / Online detection ────────────────────
  const offlineBanner  = document.getElementById('offline-banner');
  const batteryBanner  = document.getElementById('battery-banner');
  const batteryTxt     = document.getElementById('battery-banner-txt');

  function setOffline(isOffline) {
    if (offlineBanner) offlineBanner.style.display = isOffline ? 'flex' : 'none';
    if (isOffline) {
      showToast('📵 You are now offline');
      speak('You are offline. Navigation and AI detection require internet connection.');
    } else {
      showToast('✅ Back online');
    }
  }

  window.addEventListener('offline', () => setOffline(true));
  window.addEventListener('online',  () => setOffline(false));
  if (!navigator.onLine) setOffline(true);

  // ── Battery API ───────────────────────────────────
  if ('getBattery' in navigator) {
    navigator.getBattery().then(battery => {
      function onBatteryChange() {
        const pct  = Math.round(battery.level * 100);
        const low  = pct <= 20 && !battery.charging;
        const crit = pct <= 10 && !battery.charging;
        if (batteryBanner) batteryBanner.style.display = low ? 'flex' : 'none';
        if (batteryTxt)    batteryTxt.textContent = crit
          ? `Critical battery ${pct}% – please charge now`
          : `Low battery ${pct}% – GPS and detection may be reduced`;
        setHeaderBadge('hdr-gps', '📍', low ? 'warning' : 'active');
        if (crit) {
          showToast(`🔋 Critical battery: ${pct}%`);
          speak(`Warning. Battery is critically low at ${pct} percent. Please charge your device.`);
        }
      }
      onBatteryChange();
      battery.addEventListener('levelchange',   onBatteryChange);
      battery.addEventListener('chargingchange', onBatteryChange);
    }).catch(() => {}); // not all browsers support this
  }
}

/* =====================================================================
   SERVER-SIDE DETECTION LOGGING
   ===================================================================== */
const _detLogThrottle = {}; // prevent spam
async function logDetectionToServer(label, distance, risk) {
  const key = label + risk;
  const now = Date.now();
  // Throttle: don't log same label+risk more than once per 30s
  if (_detLogThrottle[key] && (now - _detLogThrottle[key]) < 30000) return;
  _detLogThrottle[key] = now;
  const entry = { label, distance, risk, timestamp: new Date().toISOString() };
  const saved = await apiPost('/api/detection-log', entry);
  if (!saved) pushLocal('detection_log', entry, 200); // no server → keep on this device
}

/* =====================================================================
   DETECTION LOG EXPORT
   ===================================================================== */
function exportDetHistory(format = 'csv') {
  if (!detHistory || detHistory.length === 0) {
    showToast('⚠ No detection history to export');
    return;
  }

  let content, mime, ext;

  if (format === 'json') {
    content = JSON.stringify(detHistory, null, 2);
    mime    = 'application/json';
    ext     = 'json';
  } else {
    // CSV
    const rows = [['Timestamp','Label','Distance (m)','Risk']];
    detHistory.forEach(e => rows.push([e.ts, e.label, e.dist < 50 ? e.dist : '>50', e.risk]));
    content = rows.map(r => r.map(v => `"${String(v).replace(/"/g, '""')}"`).join(',')).join('\n');
    mime    = 'text/csv';
    ext     = 'csv';
  }

  const blob = new Blob([content], { type: mime });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href     = url;
  a.download = `accesslens-detections-${new Date().toISOString().slice(0,10)}.${ext}`;
  a.click();
  URL.revokeObjectURL(url);
  showToast(`📥 Exported ${detHistory.length} entries as ${ext.toUpperCase()}`);
}

/* =====================================================================
   ONBOARDING MODAL
   ===================================================================== */
function checkOnboarding() {
  const completed = loadSetting('onboardingDone', false);
  if (completed) return;
  const ov = document.getElementById('onboard-overlay');
  if (!ov) return;
  ov.removeAttribute('hidden');
  ov.style.display = 'flex';
  // Focus the start button for accessibility
  setTimeout(() => document.getElementById('onboard-start-btn')?.focus(), 300);
}

function finishOnboarding() {
  const nameInput = document.getElementById('onboard-name');
  const userName  = nameInput?.value?.trim();
  if (userName) {
    saveSetting('userName', userName);
    // Personalise the greeting on home screen
    const tagline = document.querySelector('.app-tagline');
    if (tagline) tagline.textContent = `Hi ${userName} – AI Navigation Assistant`;
  }
  saveSetting('onboardingDone', true);
  const ov = document.getElementById('onboard-overlay');
  if (ov) {
    ov.style.opacity = '0'; ov.style.transition = 'opacity 0.3s';
    setTimeout(() => { ov.setAttribute('hidden', ''); ov.style.display = 'none'; ov.style.opacity = ''; }, 320);
  }
  showToast('👋 Welcome to AccessLens!');
  speak('Welcome to AccessLens. Your AI-powered navigation assistant is ready.');
}

/* =====================================================================
   FEEDBACK MODAL
   ===================================================================== */
let _fbType   = 'general';
let _fbRating = 0;

function openFeedbackModal() {
  const modal = document.getElementById('feedback-modal');
  if (!modal) return;
  _fbType   = 'general';
  _fbRating = 0;
  // Reset state
  document.querySelectorAll('.fb-type-btn').forEach(b => {
    b.classList.toggle('active', b.dataset.type === 'general');
    b.setAttribute('aria-pressed', b.dataset.type === 'general');
  });
  document.querySelectorAll('.fb-star').forEach(s => s.classList.remove('active'));
  const ta = document.getElementById('feedback-text');
  if (ta) ta.value = '';
  modal.removeAttribute('hidden');
  modal.style.display = 'flex';
  setTimeout(() => document.getElementById('feedback-text')?.focus(), 100);
}

function closeFeedbackModal() {
  const modal = document.getElementById('feedback-modal');
  if (!modal) return;
  modal.setAttribute('hidden', '');
  modal.style.display = 'none';
}

function setFbType(btn) {
  _fbType = btn.dataset.type || 'general';
  document.querySelectorAll('.fb-type-btn').forEach(b => {
    b.classList.toggle('active', b === btn);
    b.setAttribute('aria-pressed', b === btn);
  });
}

function setFbRating(val) {
  _fbRating = val;
  document.querySelectorAll('.fb-star').forEach(s => {
    s.classList.toggle('active', parseInt(s.dataset.val) <= val);
  });
}

async function submitFeedback() {
  const ta  = document.getElementById('feedback-text');
  const msg = ta?.value?.trim();
  if (!msg) { showToast('⚠ Please describe your feedback'); return; }

  const payload = { type: _fbType, message: msg, rating: _fbRating || null };

  const sent = await apiPost('/api/feedback', payload);
  if (sent) {
    showToast('✓ Feedback sent – thank you!');
    speak('Feedback submitted. Thank you for helping improve AccessLens.');
  } else {
    pushLocal('feedback', { ...payload, timestamp: new Date().toISOString() }, 100);
    showToast('✓ Feedback saved on this device – thank you!');
    speak('Feedback saved on this device. Thank you.');
  }
  closeFeedbackModal();
}

/* =====================================================================
   INDOOR MODE BADGE ELEMENT (injected if missing)
   ===================================================================== */
document.addEventListener('DOMContentLoaded', () => {
  if (!document.getElementById('indoor-mode-badge')) {
    const badge = document.createElement('div');
    badge.id        = 'indoor-mode-badge';
    badge.className = 'indoor-mode-badge';
    badge.textContent = '🏢 INDOOR MODE';
    badge.setAttribute('aria-hidden', 'true');
    document.body.appendChild(badge);
  }

  // Apply user name from settings
  const userName = loadSetting('userName', '');
  if (userName) {
    const tagline = document.querySelector('.app-tagline');
    if (tagline) tagline.textContent = `Hi ${userName} – AI Navigation Assistant`;
  }

  // Close modals on Escape
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
      closeFeedbackModal();
    }
  });
});
